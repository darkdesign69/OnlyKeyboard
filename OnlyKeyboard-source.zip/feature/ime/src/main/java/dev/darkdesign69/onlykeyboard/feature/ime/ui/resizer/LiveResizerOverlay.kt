﻿package dev.darkdesign69.onlykeyboard.feature.ime.ui.resizer

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.DragHandle
import androidx.compose.material.icons.outlined.RestartAlt
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.LayoutCoordinates
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import dev.darkdesign69.onlykeyboard.theme.KiebordTheme

@Composable
fun LiveResizerOverlay(
    dragRowHeight: Dp,
    dragChinPadding: Dp,
    dragHorizontalMargin: Dp,
    rectHeight: Dp,
    rectBottomPadding: Dp,
    onDragRowHeightChange: (Dp) -> Unit,
    onDragChinPaddingChange: (Dp) -> Unit,
    onDragHorizontalMarginChange: (Dp) -> Unit,
    onCommitDrag: () -> Unit,
    onReset: () -> Unit,
    onDone: () -> Unit,
    onCancel: () -> Unit,
    oneHandedStart: Dp = 0.dp,
    oneHandedEnd: Dp = 0.dp,
    baseRowHeight: Dp = 61.dp,
    effectiveNavBarBottom: Dp = 0.dp,
    modifier: Modifier = Modifier
) {
    val colorScheme = KiebordTheme.colorScheme
    val accentColor = colorScheme.accentColor
    val density = LocalDensity.current

    val currentHeightState = rememberUpdatedState(dragRowHeight)
    val onHeightChangeState = rememberUpdatedState(onDragRowHeightChange)

    val currentChinState = rememberUpdatedState(dragChinPadding)
    val onChinChangeState = rememberUpdatedState(onDragChinPaddingChange)

    val currentMarginState = rememberUpdatedState(dragHorizontalMargin)
    val onMarginChangeState = rememberUpdatedState(onDragHorizontalMarginChange)

    val onCommitState = rememberUpdatedState(onCommitDrag)
    val effectiveNavBarBottomState = rememberUpdatedState(effectiveNavBarBottom)

    val rectStartInset = 6.dp + dragHorizontalMargin + oneHandedStart
    val rectEndInset = 6.dp + dragHorizontalMargin + oneHandedEnd

    var overlayCoordinates by remember { mutableStateOf<LayoutCoordinates?>(null) }

    var topHandleCoords by remember { mutableStateOf<LayoutCoordinates?>(null) }
    var gestureStartYTop by remember { mutableStateOf(0f) }
    var gestureStartHeight by remember { mutableStateOf(0.dp) }

    var leftHandleCoords by remember { mutableStateOf<LayoutCoordinates?>(null) }
    var gestureStartXLeft by remember { mutableStateOf(0f) }
    var gestureStartMarginLeft by remember { mutableStateOf(0.dp) }

    var rightHandleCoords by remember { mutableStateOf<LayoutCoordinates?>(null) }
    var gestureStartXRight by remember { mutableStateOf(0f) }
    var gestureStartMarginRight by remember { mutableStateOf(0.dp) }

    var bottomHandleCoords by remember { mutableStateOf<LayoutCoordinates?>(null) }
    var gestureStartYBottom by remember { mutableStateOf(0f) }
    var gestureStartChin by remember { mutableStateOf(0.dp) }

    var centerHandleCoords by remember { mutableStateOf<LayoutCoordinates?>(null) }
    var gestureStartCenterChin by remember { mutableStateOf(0.dp) }
    var gestureStartCenterMargin by remember { mutableStateOf(0.dp) }
    var gestureStartCenterX by remember { mutableStateOf(0f) }
    var gestureStartCenterY by remember { mutableStateOf(0f) }

    Box(
        modifier = modifier.onGloballyPositioned { overlayCoordinates = it }
    ) {
        // Bounding wireframe outline with touch-safe handles
        Box(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(
                    start = rectStartInset,
                    end = rectEndInset,
                    bottom = rectBottomPadding
                )
                .fillMaxWidth()
                .height(rectHeight)
                .border(2.dp, accentColor, RoundedCornerShape(12.dp))
        ) {
            // 1. Semi-transparent backdrop that absorbs touches in empty space without starving handles
            Box(
                modifier = Modifier
                    .matchParentSize()
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color.Black.copy(alpha = 0.32f))
                    .pointerInput(Unit) {
                        awaitEachGesture {
                            val down = awaitFirstDown(requireUnconsumed = true)
                            down.consume()
                            while (true) {
                                val event = awaitPointerEvent()
                                event.changes.forEach { it.consume() }
                                if (event.changes.all { !it.pressed }) break
                            }
                        }
                    }
            )

            // 2. Top Drag Handle (large 48dp touch target, centered 64x10 pill for height resizing)
            Box(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .fillMaxWidth(0.6f)
                    .height(48.dp)
                    .onGloballyPositioned { topHandleCoords = it }
                    .pointerInput(Unit) {
                        detectDragGestures(
                            onDragStart = { offset ->
                                val oCoords = overlayCoordinates
                                val hCoords = topHandleCoords
                                if (oCoords != null && hCoords != null && oCoords.isAttached && hCoords.isAttached) {
                                    gestureStartYTop = oCoords.localPositionOf(hCoords, offset).y
                                    gestureStartHeight = currentHeightState.value
                                }
                            },
                            onDrag = { change, _ ->
                                change.consume()
                                val oCoords = overlayCoordinates
                                val hCoords = topHandleCoords
                                if (oCoords != null && hCoords != null && oCoords.isAttached && hCoords.isAttached) {
                                    val currentY = oCoords.localPositionOf(hCoords, change.position).y
                                    val deltaY = gestureStartYTop - currentY
                                    val deltaRowDp = with(density) { (deltaY / 4.8f).toDp() }
                                    val minAllowedHeight = (baseRowHeight * 0.65f).coerceAtLeast(22.dp)
                                    val maxAllowedHeight = (baseRowHeight * 1.45f).coerceAtMost(90.dp)
                                    val newHeight = (gestureStartHeight + deltaRowDp).coerceIn(minAllowedHeight, maxAllowedHeight)
                                    onHeightChangeState.value(newHeight)
                                }
                            },
                            onDragEnd = { onCommitState.value() },
                            onDragCancel = { onCommitState.value() }
                        )
                    },
                contentAlignment = Alignment.TopCenter
            ) {
                Box(
                    modifier = Modifier
                        .padding(top = 2.dp)
                        .width(64.dp)
                        .height(10.dp)
                        .shadow(elevation = 6.dp, shape = RoundedCornerShape(5.dp))
                        .clip(RoundedCornerShape(5.dp))
                        .background(accentColor),
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .width(20.dp)
                            .height(2.dp)
                            .background(Color.White.copy(alpha = 0.75f), RoundedCornerShape(1.dp))
                    )
                }
            }

            // 3. Left Drag Handle (large 48dp touch target, centered 10x56 pill for horizontal width/margin)
            Box(
                modifier = Modifier
                    .align(Alignment.CenterStart)
                    .width(48.dp)
                    .height(110.dp)
                    .onGloballyPositioned { leftHandleCoords = it }
                    .pointerInput(Unit) {
                        detectDragGestures(
                            onDragStart = { offset ->
                                val oCoords = overlayCoordinates
                                val hCoords = leftHandleCoords
                                if (oCoords != null && hCoords != null && oCoords.isAttached && hCoords.isAttached) {
                                    gestureStartXLeft = oCoords.localPositionOf(hCoords, offset).x
                                    gestureStartMarginLeft = currentMarginState.value
                                }
                            },
                            onDrag = { change, _ ->
                                change.consume()
                                val oCoords = overlayCoordinates
                                val hCoords = leftHandleCoords
                                if (oCoords != null && hCoords != null && oCoords.isAttached && hCoords.isAttached) {
                                    val currentX = oCoords.localPositionOf(hCoords, change.position).x
                                    val deltaX = currentX - gestureStartXLeft
                                    val deltaMarginDp = with(density) { (deltaX / 2f).toDp() }
                                    val newMargin = (gestureStartMarginLeft + deltaMarginDp).coerceIn(0.dp, 48.dp)
                                    onMarginChangeState.value(newMargin)
                                }
                            },
                            onDragEnd = { onCommitState.value() },
                            onDragCancel = { onCommitState.value() }
                        )
                    },
                contentAlignment = Alignment.CenterStart
            ) {
                Box(
                    modifier = Modifier
                        .padding(start = 2.dp)
                        .width(10.dp)
                        .height(56.dp)
                        .shadow(elevation = 6.dp, shape = RoundedCornerShape(5.dp))
                        .clip(RoundedCornerShape(5.dp))
                        .background(accentColor),
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .width(2.dp)
                            .height(20.dp)
                            .background(Color.White.copy(alpha = 0.75f), RoundedCornerShape(1.dp))
                    )
                }
            }

            // 4. Right Drag Handle (large 48dp touch target, centered 10x56 pill for horizontal width/margin)
            Box(
                modifier = Modifier
                    .align(Alignment.CenterEnd)
                    .width(48.dp)
                    .height(110.dp)
                    .onGloballyPositioned { rightHandleCoords = it }
                    .pointerInput(Unit) {
                        detectDragGestures(
                            onDragStart = { offset ->
                                val oCoords = overlayCoordinates
                                val hCoords = rightHandleCoords
                                if (oCoords != null && hCoords != null && oCoords.isAttached && hCoords.isAttached) {
                                    gestureStartXRight = oCoords.localPositionOf(hCoords, offset).x
                                    gestureStartMarginRight = currentMarginState.value
                                }
                            },
                            onDrag = { change, _ ->
                                change.consume()
                                val oCoords = overlayCoordinates
                                val hCoords = rightHandleCoords
                                if (oCoords != null && hCoords != null && oCoords.isAttached && hCoords.isAttached) {
                                    val currentX = oCoords.localPositionOf(hCoords, change.position).x
                                    val deltaX = gestureStartXRight - currentX
                                    val deltaMarginDp = with(density) { (deltaX / 2f).toDp() }
                                    val newMargin = (gestureStartMarginRight + deltaMarginDp).coerceIn(0.dp, 48.dp)
                                    onMarginChangeState.value(newMargin)
                                }
                            },
                            onDragEnd = { onCommitState.value() },
                            onDragCancel = { onCommitState.value() }
                        )
                    },
                contentAlignment = Alignment.CenterEnd
            ) {
                Box(
                    modifier = Modifier
                        .padding(end = 2.dp)
                        .width(10.dp)
                        .height(56.dp)
                        .shadow(elevation = 6.dp, shape = RoundedCornerShape(5.dp))
                        .clip(RoundedCornerShape(5.dp))
                        .background(accentColor),
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .width(2.dp)
                            .height(20.dp)
                            .background(Color.White.copy(alpha = 0.75f), RoundedCornerShape(1.dp))
                    )
                }
            }

            // 5. Bottom Drag Handle (large 48dp touch target, centered 64x10 pill for bottom chin padding)
            Box(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth(0.6f)
                    .height(48.dp)
                    .onGloballyPositioned { bottomHandleCoords = it }
                    .pointerInput(Unit) {
                        detectDragGestures(
                            onDragStart = { offset ->
                                val oCoords = overlayCoordinates
                                val hCoords = bottomHandleCoords
                                if (oCoords != null && hCoords != null && oCoords.isAttached && hCoords.isAttached) {
                                    gestureStartYBottom = oCoords.localPositionOf(hCoords, offset).y
                                    gestureStartChin = currentChinState.value
                                }
                            },
                            onDrag = { change, _ ->
                                change.consume()
                                val oCoords = overlayCoordinates
                                val hCoords = bottomHandleCoords
                                if (oCoords != null && hCoords != null && oCoords.isAttached && hCoords.isAttached) {
                                    val currentY = oCoords.localPositionOf(hCoords, change.position).y
                                    val deltaY = gestureStartYBottom - currentY
                                    val deltaChin = with(density) { deltaY.toDp() }
                                    val minChin = -effectiveNavBarBottomState.value
                                    val newChin = (gestureStartChin + deltaChin).coerceIn(minChin, 64.dp)
                                    onChinChangeState.value(newChin)
                                }
                            },
                            onDragEnd = { onCommitState.value() },
                            onDragCancel = { onCommitState.value() }
                        )
                    },
                contentAlignment = Alignment.BottomCenter
            ) {
                Box(
                    modifier = Modifier
                        .padding(bottom = 6.dp)
                        .width(64.dp)
                        .height(10.dp)
                        .shadow(elevation = 6.dp, shape = RoundedCornerShape(5.dp))
                        .clip(RoundedCornerShape(5.dp))
                        .background(accentColor),
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .width(20.dp)
                            .height(2.dp)
                            .background(Color.White.copy(alpha = 0.75f), RoundedCornerShape(1.dp))
                    )
                }
            }

            // 6. Centered Floating Action Island matching active keyboard theme
            Box(
                modifier = Modifier
                    .align(Alignment.Center)
                    .shadow(elevation = 14.dp, shape = RoundedCornerShape(26.dp))
                    .clip(RoundedCornerShape(26.dp))
                    .background(colorScheme.containerBackground)
                    .border(1.dp, colorScheme.keyForeground.copy(alpha = 0.18f), RoundedCornerShape(26.dp))
                    .padding(horizontal = 14.dp, vertical = 6.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Move / Drag Handle (Dragging here moves keyboard chin & horizontal margin)
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(colorScheme.keyForeground.copy(alpha = 0.08f))
                            .padding(horizontal = 6.dp, vertical = 6.dp)
                            .onGloballyPositioned { centerHandleCoords = it }
                            .pointerInput(Unit) {
                                detectDragGestures(
                                    onDragStart = { offset ->
                                        val oCoords = overlayCoordinates
                                        val hCoords = centerHandleCoords
                                        if (oCoords != null && hCoords != null && oCoords.isAttached && hCoords.isAttached) {
                                            val startPos = oCoords.localPositionOf(hCoords, offset)
                                            gestureStartCenterX = startPos.x
                                            gestureStartCenterY = startPos.y
                                            gestureStartCenterChin = currentChinState.value
                                            gestureStartCenterMargin = currentMarginState.value
                                        }
                                    },
                                    onDrag = { change, _ ->
                                        change.consume()
                                        val oCoords = overlayCoordinates
                                        val hCoords = centerHandleCoords
                                        if (oCoords != null && hCoords != null && oCoords.isAttached && hCoords.isAttached) {
                                            val currentPos = oCoords.localPositionOf(hCoords, change.position)
                                            val deltaY = gestureStartCenterY - currentPos.y
                                            val deltaChin = with(density) { deltaY.toDp() }
                                            val minChin = -effectiveNavBarBottomState.value
                                            val newChin = (gestureStartCenterChin + deltaChin).coerceIn(minChin, 64.dp)
                                            onChinChangeState.value(newChin)

                                            val deltaX = currentPos.x - gestureStartCenterX
                                            val deltaMargin = with(density) { (deltaX / 2f).toDp() }
                                            val newMargin = (gestureStartCenterMargin + deltaMargin).coerceIn(0.dp, 48.dp)
                                            onMarginChangeState.value(newMargin)
                                        }
                                    },
                                    onDragEnd = { onCommitState.value() },
                                    onDragCancel = { onCommitState.value() }
                                )
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.DragHandle,
                            contentDescription = "Move Keyboard",
                            tint = colorScheme.keyForeground.copy(alpha = 0.85f),
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    // Divider
                    Box(
                        modifier = Modifier
                            .width(1.dp)
                            .height(20.dp)
                            .background(colorScheme.keyForeground.copy(alpha = 0.15f))
                    )

                    // Reset Button
                    IconButton(
                        onClick = onReset,
                        modifier = Modifier.size(34.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.RestartAlt,
                            contentDescription = "Reset",
                            tint = colorScheme.keyForeground,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    // Scale / Height readout percentage
                    Text(
                        text = "${(dragRowHeight.value / (if (baseRowHeight.value > 0f) baseRowHeight.value else 61f) * 100).toInt()}%",
                        color = colorScheme.keyForeground,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )

                    // Divider
                    Box(
                        modifier = Modifier
                            .width(1.dp)
                            .height(20.dp)
                            .background(colorScheme.keyForeground.copy(alpha = 0.15f))
                    )

                    // Cancel Button
                    IconButton(
                        onClick = onCancel,
                        modifier = Modifier.size(34.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Close,
                            contentDescription = "Cancel",
                            tint = colorScheme.keyForeground.copy(alpha = 0.85f),
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    // Save / Confirm Button (Accent circle with white checkmark)
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(accentColor),
                        contentAlignment = Alignment.Center
                    ) {
                        IconButton(
                            onClick = onDone,
                            modifier = Modifier.size(34.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.Check,
                                contentDescription = "Save",
                                tint = Color.White,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}
