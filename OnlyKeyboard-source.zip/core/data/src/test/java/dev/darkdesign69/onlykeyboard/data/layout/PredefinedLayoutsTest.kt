package dev.darkdesign69.onlykeyboard.data.layout

import dev.darkdesign69.onlykeyboard.common.model.KeyType
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PredefinedLayoutsTest {

    @Test
    fun testLayoutDisplayNames() {
        assertEquals("English", PredefinedLayouts.displayName("en_qwerty"))
        assertEquals("জাতীয় (BSTI)", PredefinedLayouts.displayName("bn_national"))
        assertEquals("বর্ণ ফোনেটিক", PredefinedLayouts.displayName("bn_borno"))
        assertEquals("অভ্র", PredefinedLayouts.displayName("bn_avro"))
        assertEquals("প্রভাত", PredefinedLayouts.displayName("bn_probhat"))
        assertEquals("Arabic", PredefinedLayouts.displayName("ar_arabic"))
        assertEquals("বর্ণ ইজি", PredefinedLayouts.displayName("bn_easy"))
        assertEquals("বর্ণ ইজি", PredefinedLayouts.displayName("borno_easy"))
        assertEquals("Number Pad", PredefinedLayouts.displayName("num_extended"))
        assertEquals("123", PredefinedLayouts.displayName("num_normal"))
        assertEquals("Date & Time", PredefinedLayouts.displayName("num_datetime"))
        assertEquals("Phone", PredefinedLayouts.displayName("num_phone"))
        assertEquals("PIN", PredefinedLayouts.displayName("num_password"))
    }

    @Test
    fun testBengaliBornoEasyLayoutResolution() {
        val layout = PredefinedLayouts.fromId("bn_easy")
        assertEquals("bn_easy", layout.id)
        assertEquals("বর্ণ ইজি", layout.name)
        assertEquals(6, layout.rows.size)

        // Row 0: Vowels (11 keys)
        val r0 = layout.rows[0].keys
        assertEquals(11, r0.size)
        assertEquals("অ", r0[0].label)
        assertEquals("আ", r0[1].label)
        assertEquals("া", r0[1].flickUp)
        assertTrue(r0[1].moreKeys.isEmpty())
        assertEquals("ঔ", r0[10].label)
        assertEquals("ৌ", r0[10].flickUp)

        // Rows 1-3: Consonants (10 keys each)
        val r1 = layout.rows[1].keys
        assertEquals(10, r1.size)
        assertEquals("ক", r1[0].label)
        assertEquals(listOf("ক্ষ", "ক্ত", "ক্ক", "ক্ল", "ক্স"), r1[0].moreKeys)
        assertEquals("খ", r1[1].label)
        assertTrue(r1[1].moreKeys.isEmpty())
        assertEquals("ঞ", r1[9].label)
        assertEquals(listOf("ঞ্চ", "ঞ্জ", "ঞ্ছ", "ঞ্ঝ"), r1[9].moreKeys)

        val r2 = layout.rows[2].keys
        assertEquals(10, r2.size)
        assertEquals("ট", r2[0].label)
        assertEquals(listOf("ট্ট"), r2[0].moreKeys)
        assertEquals("ন", r2[9].label)
        assertEquals(listOf("ন্ত", "ন্দ", "ন্ধ", "ন্ন", "ন্ম", "ন্থ", "ন্ব", "ন্ট", "ন্স"), r2[9].moreKeys)

        val r3 = layout.rows[3].keys
        assertEquals(10, r3.size)
        assertEquals("প", r3[0].label)
        assertEquals(listOf("প্ত", "প্ল", "প্ন", "প্প", "প্স"), r3[0].moreKeys)
        assertEquals("য", r3[5].label)
        assertEquals(listOf("্য"), r3[5].moreKeys)
        assertEquals("র", r3[6].label)
        assertEquals(listOf("্র", "র্"), r3[6].moreKeys)
        assertEquals("ষ", r3[9].label)
        assertEquals(listOf("ষ্ট", "ষ্ঠ", "ষ্ণ", "ষ্প", "ষ্ক", "ষ্ম", "ষ্ফ", "ক্ষ"), r3[9].moreKeys)

        // Row 4: স..্ + Delete (11 keys)
        val r4 = layout.rows[4].keys
        assertEquals(11, r4.size)
        assertEquals("স", r4[0].label)
        assertEquals(listOf("স্ত", "স্থ", "স্প", "স্ব", "স্ম", "স্ক", "স্ট", "স্ন", "স্ল", "স্ফ", "স্খ", "ACTION_SELECT_ALL"), r4[0].moreKeys)
        assertEquals("হ", r4[1].label)
        assertEquals(listOf("হ্ম", "হ্ন", "হ্ব", "হ্ণ", "হ্ল", "হৃ", "ACTION_CUT"), r4[1].moreKeys)
        assertEquals("ড়", r4[2].label)
        assertEquals(listOf("ড়্গ", "ACTION_COPY"), r4[2].moreKeys)
        assertEquals("ঢ়", r4[3].label)
        assertEquals(listOf("ACTION_PASTE"), r4[3].moreKeys)
        assertEquals("ৎ", r4[5].label)
        assertTrue("ৎ must not have ৎস", r4[5].moreKeys.isEmpty())
        assertEquals("্", r4[9].label)
        assertEquals(listOf("্য", "্র", "়"), r4[9].moreKeys)
        assertEquals(KeyType.DELETE, r4[10].type)

        // Row 5: Function & spacebar row (6 keys without ZWNJ)
        val r5 = layout.rows[5].keys
        assertEquals(6, r5.size)
        assertEquals(KeyType.SYMBOLS, r5[0].type)
        assertEquals(KeyType.SPACE, r5[3].type)
        assertEquals(4.0f, r5[3].widthWeight, 0.01f)
        assertEquals("।", r5[4].label)
        assertEquals(KeyType.ACTION, r5[5].type)

        // Test dynamic first row: Vowel Mode
        val vowelRow = PredefinedLayouts.getBornoEasyFirstRow(isKarMode = false)
        assertEquals(11, vowelRow.keys.size)
        assertEquals("অ", vowelRow.keys[0].label)
        assertEquals("আ", vowelRow.keys[1].label)

        // Test dynamic first row: Kar Mode with consonant "ক"
        val karRowKo = PredefinedLayouts.getBornoEasyFirstRow(isKarMode = true, cluster = "ক")
        assertEquals(11, karRowKo.keys.size)
        assertEquals("ZW\nNJ", karRowKo.keys[0].label)
        assertEquals("\u200C", karRowKo.keys[0].commitText)
        assertEquals("কা", karRowKo.keys[1].label)
        assertEquals("া", karRowKo.keys[1].commitText)
        assertEquals("কি", karRowKo.keys[2].label)
        assertEquals("ি", karRowKo.keys[2].commitText)
        assertEquals("কৌ", karRowKo.keys[10].label)
        assertEquals("ৌ", karRowKo.keys[10].commitText)

        // Test dynamic first row: Kar Mode with conjunct "ক্ত"
        val karRowKto = PredefinedLayouts.getBornoEasyFirstRow(isKarMode = true, cluster = "ক্ত")
        assertEquals(11, karRowKto.keys.size)
        assertEquals("ZW\nNJ", karRowKto.keys[0].label)
        assertEquals("\u200C", karRowKto.keys[0].commitText)
        assertEquals("ক্তা", karRowKto.keys[1].label)
        assertEquals("া", karRowKto.keys[1].commitText)
        assertEquals("ক্তি", karRowKto.keys[2].label)
        assertEquals("ি", karRowKto.keys[2].commitText)
        assertEquals("ক্তৌ", karRowKto.keys[10].label)
        assertEquals("ৌ", karRowKto.keys[10].commitText)
    }

    @Test
    fun testAvroLayoutResolution() {
        val layout = PredefinedLayouts.fromId("bn_avro")
        assertEquals("bn_avro", layout.id)
        assertEquals("অভ্র", layout.name)
        assertEquals(4, layout.rows.size)

        // Key 'a' in home row has no ঁ
        val keyA = layout.rows[1].keys[0]
        assertEquals("a", keyA.label)
        assertEquals("@", keyA.flickUp)
        assertEquals(listOf("@"), keyA.moreKeys)

        // Key 'l' in home row has no ঃ
        val keyL = layout.rows[1].keys[8]
        assertEquals("l", keyL.label)
        assertEquals(")", keyL.flickUp)
        assertEquals(listOf(")"), keyL.moreKeys)
    }

    @Test
    fun testNationalLayoutResolution() {
        val layout = PredefinedLayouts.fromId("bn_national")
        assertEquals("bn_national", layout.id)
        assertEquals("bn_fixed", layout.processor)
        assertEquals("bn_fixed", PredefinedLayouts.BengaliProbhat.processor)
        assertEquals("bn_fixed", PredefinedLayouts.BengaliBornoEasy.processor)
        assertEquals(4, layout.rows.size)

        // Top row
        val topRowKeys = layout.rows[0].keys
        assertEquals(10, topRowKeys.size)
        assertEquals("ঙ", topRowKeys[0].label)
        assertEquals("ং", topRowKeys[0].shiftedLabel)
        assertEquals(emptyList<String>(), topRowKeys[0].moreKeys(dev.darkdesign69.onlykeyboard.common.model.ShiftState.UNSHIFTED))
        assertEquals(listOf("ঙ্ক"), topRowKeys[0].moreKeys(dev.darkdesign69.onlykeyboard.common.model.ShiftState.ONE_SHOT))
        assertEquals("ঙ্ক", topRowKeys[0].flickUp(dev.darkdesign69.onlykeyboard.common.model.ShiftState.ONE_SHOT))

        assertEquals("য", topRowKeys[1].label)
        assertEquals("য়", topRowKeys[1].shiftedLabel)
        assertEquals(emptyList<String>(), topRowKeys[1].moreKeys(dev.darkdesign69.onlykeyboard.common.model.ShiftState.UNSHIFTED))
        assertEquals(listOf("ঞ্ঝ"), topRowKeys[1].moreKeys(dev.darkdesign69.onlykeyboard.common.model.ShiftState.ONE_SHOT))

        // Home row
        val homeRowKeys = layout.rows[1].keys
        assertEquals(9, homeRowKeys.size)
        assertEquals("ৃ", homeRowKeys[0].label)
        assertEquals("র্", homeRowKeys[0].shiftedLabel)
        assertEquals(listOf("ঋ"), homeRowKeys[0].moreKeys(dev.darkdesign69.onlykeyboard.common.model.ShiftState.UNSHIFTED))
        assertEquals(emptyList<String>(), homeRowKeys[0].moreKeys(dev.darkdesign69.onlykeyboard.common.model.ShiftState.ONE_SHOT))

        assertEquals("ত", homeRowKeys[7].label)
        assertEquals("থ", homeRowKeys[7].shiftedLabel)
        assertEquals(listOf("ৎ"), homeRowKeys[7].moreKeys(dev.darkdesign69.onlykeyboard.common.model.ShiftState.UNSHIFTED))
        assertEquals(emptyList<String>(), homeRowKeys[7].moreKeys(dev.darkdesign69.onlykeyboard.common.model.ShiftState.ONE_SHOT))

        // Bottom row
        val bottomRowKeys = layout.rows[2].keys
        assertEquals(9, bottomRowKeys.size)
        assertEquals(KeyType.SHIFT, bottomRowKeys[0].type)
        assertEquals("্র", bottomRowKeys[1].label)
        assertEquals("্য", bottomRowKeys[1].shiftedLabel)

        assertEquals("ো", bottomRowKeys[2].label)
        assertEquals("ৌ", bottomRowKeys[2].shiftedLabel)
        assertEquals(listOf("ও"), bottomRowKeys[2].moreKeys(dev.darkdesign69.onlykeyboard.common.model.ShiftState.UNSHIFTED))
        assertEquals(listOf("ঔ"), bottomRowKeys[2].moreKeys(dev.darkdesign69.onlykeyboard.common.model.ShiftState.ONE_SHOT))

        assertEquals("ে", bottomRowKeys[3].label)
        assertEquals("ৈ", bottomRowKeys[3].shiftedLabel)
        assertEquals(listOf("এ"), bottomRowKeys[3].moreKeys(dev.darkdesign69.onlykeyboard.common.model.ShiftState.UNSHIFTED))
        assertEquals(listOf("ঐ"), bottomRowKeys[3].moreKeys(dev.darkdesign69.onlykeyboard.common.model.ShiftState.ONE_SHOT))

        assertEquals("র", bottomRowKeys[4].label)
        assertEquals("ল", bottomRowKeys[4].shiftedLabel)
        assertEquals(listOf("ব়্য"), bottomRowKeys[4].moreKeys(dev.darkdesign69.onlykeyboard.common.model.ShiftState.ONE_SHOT))

        assertEquals("ন", bottomRowKeys[5].label)
        assertEquals("ণ", bottomRowKeys[5].shiftedLabel)
        assertEquals(listOf("ঞ্চ"), bottomRowKeys[5].moreKeys(dev.darkdesign69.onlykeyboard.common.model.ShiftState.ONE_SHOT))

        assertEquals("স", bottomRowKeys[6].label)
        assertEquals("ষ", bottomRowKeys[6].shiftedLabel)
        assertEquals(listOf("ষ্ণ"), bottomRowKeys[6].moreKeys(dev.darkdesign69.onlykeyboard.common.model.ShiftState.ONE_SHOT))

        assertEquals("ম", bottomRowKeys[7].label)
        assertEquals("শ", bottomRowKeys[7].shiftedLabel)
        assertEquals(listOf("ঃ"), bottomRowKeys[7].moreKeys(dev.darkdesign69.onlykeyboard.common.model.ShiftState.UNSHIFTED))
        assertEquals(listOf("হ্ম"), bottomRowKeys[7].moreKeys(dev.darkdesign69.onlykeyboard.common.model.ShiftState.ONE_SHOT))

        assertEquals(KeyType.DELETE, bottomRowKeys[8].type)

        // Row 4
        val row4Keys = layout.rows[3].keys
        assertEquals(6, row4Keys.size)
        assertEquals(KeyType.SYMBOLS, row4Keys[0].type)
        assertEquals(",", row4Keys[1].label)
        assertTrue(row4Keys[1].moreKeys.contains("ACTION_SETTINGS"))
        assertTrue(row4Keys[1].moreKeys.contains("ACTION_ONE_HANDED"))
        assertEquals(KeyType.SWITCH_LANGUAGE, row4Keys[2].type)
        assertEquals(KeyType.SPACE, row4Keys[3].type)
        assertEquals("।", row4Keys[4].label)
        assertEquals(KeyType.ACTION, row4Keys[5].type)

        // Verify national layout key hints match first moreKeys and dummy secondary hints are removed for each shift state
        for (state in listOf(dev.darkdesign69.onlykeyboard.common.model.ShiftState.UNSHIFTED, dev.darkdesign69.onlykeyboard.common.model.ShiftState.ONE_SHOT)) {
            for (row in layout.rows) {
                for (key in row.keys) {
                    val mk = key.moreKeys(state)
                    val hint = key.flickUp(state)
                    if (mk.isEmpty() || mk.first().startsWith("ACTION_") || key.label == "।") {
                        org.junit.Assert.assertNull("Key ${key.label} in state $state without character moreKeys should not have flickUp", hint)
                    } else {
                        assertEquals("Key ${key.label} in state $state flickUp must match moreKeys.first()", mk.first(), hint)
                    }
                }
            }
        }
    }

    @Test
    fun testSymbolsLayoutsWithAndWithoutNumberRow() {
        val standard = PredefinedLayouts.getSymbolsLayout("symbols_1", hasNumberRow = false)
        assertEquals("symbols_1", standard.id)
        assertEquals(4, standard.rows.size)
        // Row 0 is numbers
        assertEquals("1", standard.rows[0].keys[0].label)
        assertEquals("0", standard.rows[0].keys[9].label)
        // Row 1 is @, #, $, %, etc.
        assertEquals("@", standard.rows[1].keys[0].label)
        assertEquals("ZW\nNJ", standard.rows[1].keys[9].label)
        assertEquals("\u200C", standard.rows[1].keys[9].textToCommit(dev.darkdesign69.onlykeyboard.common.model.ShiftState.UNSHIFTED))
        // Row 2 is =<, *, ", etc.
        assertEquals("=\\<", standard.rows[2].keys[0].label)
        // Row 3 is ABC, comma, underscore, space, slash, period, enter
        assertEquals("ABC", standard.rows[3].keys[0].label)
        assertEquals(",", standard.rows[3].keys[1].label)
        assertEquals("_", standard.rows[3].keys[2].label)
        assertEquals(KeyType.SPACE, standard.rows[3].keys[3].type)
        assertEquals("/", standard.rows[3].keys[4].label)
        assertEquals(".", standard.rows[3].keys[5].label)

        // With extra row (number row enabled)
        val withExtra = PredefinedLayouts.getSymbolsLayout("symbols_1", hasNumberRow = true)
        assertEquals(5, withExtra.rows.size)
        // Row 0 is numbers
        assertEquals("1", withExtra.rows[0].keys[0].label)
        // Row 1 is the EXTRA ROW from Borno XML reference: ~ < > _ ` º \ = { }
        val extraRow = withExtra.rows[1].keys
        assertEquals(10, extraRow.size)
        assertEquals("~", extraRow[0].label)
        assertEquals("<", extraRow[1].label)
        assertEquals(">", extraRow[2].label)
        assertEquals("_", extraRow[3].label)
        assertEquals("`", extraRow[4].label)
        assertEquals("º", extraRow[5].label)
        assertEquals("\\", extraRow[6].label)
        assertEquals("=", extraRow[7].label)
        assertEquals("{", extraRow[8].label)
        assertEquals("}", extraRow[9].label)
        // Row 2 is @, #, $...
        assertEquals("@", withExtra.rows[2].keys[0].label)
        // Row 3 is =<...
        assertEquals("=\\<", withExtra.rows[3].keys[0].label)
        // Row 4 is ABC...
        assertEquals("ABC", withExtra.rows[4].keys[0].label)
    }

    @Test
    fun testSymbolsMoreLayoutsWithAndWithoutNumberRow() {
        val standard = PredefinedLayouts.getSymbolsLayout("symbols_2", hasNumberRow = false)
        assertEquals("symbols_2", standard.id)
        assertEquals(4, standard.rows.size)
        assertEquals("~", standard.rows[0].keys[0].label)
        assertEquals("∆", standard.rows[0].keys[9].label)
        assertEquals("£", standard.rows[1].keys[0].label)
        assertEquals("?123", standard.rows[2].keys[0].label)
        assertEquals("ABC", standard.rows[3].keys[0].label)

        // With extra shift row (number row enabled)
        val withExtra = PredefinedLayouts.getSymbolsLayout("symbols_2", hasNumberRow = true)
        assertEquals(5, withExtra.rows.size)
        assertEquals("~", withExtra.rows[0].keys[0].label)
        // Row 1 is the EXTRA SHIFT ROW from Borno XML reference: ≠ ≤ ≥ ∫ Σ ≈ ± ∓ ½ ∞
        val extraShiftRow = withExtra.rows[1].keys
        assertEquals(10, extraShiftRow.size)
        assertEquals("≠", extraShiftRow[0].label)
        assertEquals("≤", extraShiftRow[1].label)
        assertEquals("≥", extraShiftRow[2].label)
        assertEquals("∫", extraShiftRow[3].label)
        assertEquals("Σ", extraShiftRow[4].label)
        assertEquals("≈", extraShiftRow[5].label)
        assertEquals("±", extraShiftRow[6].label)
        assertEquals("∓", extraShiftRow[7].label)
        assertEquals("½", extraShiftRow[8].label)
        assertEquals("∞", extraShiftRow[9].label)
        // Row 2 is £, ¢...
        assertEquals("£", withExtra.rows[2].keys[0].label)
        // Row 3 is ?123...
        assertEquals("?123", withExtra.rows[3].keys[0].label)
        // Row 4 is ABC...
        assertEquals("ABC", withExtra.rows[4].keys[0].label)
    }

    @Test
    fun testNumberRowsHaveNoSecondaryFlickUp() {
        val bnRow = PredefinedLayouts.createNumberRow("bn")
        assertEquals(10, bnRow.keys.size)
        for (k in bnRow.keys) {
            org.junit.Assert.assertNull("Bengali number row key ${k.label} should not have flickUp", k.flickUp)
        }

        val enRow = PredefinedLayouts.createNumberRow("en")
        assertEquals(10, enRow.keys.size)
        for (k in enRow.keys) {
            org.junit.Assert.assertNull("English number row key ${k.label} should not have flickUp", k.flickUp)
        }
    }

    @Test
    fun testCustomLayoutResolverAndDisplayName() {
        val originalResolver = PredefinedLayouts.customLayoutResolver
        try {
            PredefinedLayouts.customLayoutResolver = { id ->
                if (id == "custom_layout_1") "Custom Layout" else null
            }
            assertEquals("Custom Layout", PredefinedLayouts.displayName("custom_layout_1"))
            assertEquals("English", PredefinedLayouts.displayName("en_qwerty"))
        } finally {
            PredefinedLayouts.customLayoutResolver = originalResolver
        }
    }

    @Test
    fun testNumberRowShiftedSymbols() {
        val enRow = PredefinedLayouts.NumberRowEn
        assertEquals("1", enRow.keys[0].textToCommit(dev.darkdesign69.onlykeyboard.common.model.ShiftState.UNSHIFTED))
        assertEquals("!", enRow.keys[0].textToCommit(dev.darkdesign69.onlykeyboard.common.model.ShiftState.ONE_SHOT))
        assertEquals("!", enRow.keys[0].textToCommit(dev.darkdesign69.onlykeyboard.common.model.ShiftState.CAPS_LOCK))

        val bnRow = PredefinedLayouts.NumberRowBn
        assertEquals("৪", bnRow.keys[3].textToCommit(dev.darkdesign69.onlykeyboard.common.model.ShiftState.UNSHIFTED))
        assertEquals("৳", bnRow.keys[3].textToCommit(dev.darkdesign69.onlykeyboard.common.model.ShiftState.ONE_SHOT))

        val arRow = PredefinedLayouts.NumberRowAr
        assertEquals("٥", arRow.keys[4].textToCommit(dev.darkdesign69.onlykeyboard.common.model.ShiftState.UNSHIFTED))
        assertEquals("٪", arRow.keys[4].textToCommit(dev.darkdesign69.onlykeyboard.common.model.ShiftState.ONE_SHOT))
    }

    @Test
    fun testKeyboardLayoutDefEffectiveDisplayName() {
        val withDisplay = dev.darkdesign69.onlykeyboard.common.model.KeyboardLayoutDef(
            id = "test_custom",
            name = "Test Custom Full",
            displayName = "Custom Short",
            language = "en",
            rows = emptyList()
        )
        assertEquals("Custom Short", withDisplay.effectiveDisplayName())

        val withoutDisplay = dev.darkdesign69.onlykeyboard.common.model.KeyboardLayoutDef(
            id = "test_custom_2",
            name = "Test Custom 2",
            language = "en",
            rows = emptyList()
        )
        assertEquals("Test Custom 2", withoutDisplay.effectiveDisplayName())
    }

    @Test
    fun testSymbolsLayoutResolutionAndFallback() {
        val customSym = dev.darkdesign69.onlykeyboard.common.model.KeyboardLayoutDef(
            id = "custom_sym",
            name = "Custom Symbols",
            language = "sym",
            rows = listOf(
                dev.darkdesign69.onlykeyboard.common.model.KeyRow(listOf(dev.darkdesign69.onlykeyboard.common.model.KeyDef("1"))),
                dev.darkdesign69.onlykeyboard.common.model.KeyRow(listOf(dev.darkdesign69.onlykeyboard.common.model.KeyDef("@"))),
                dev.darkdesign69.onlykeyboard.common.model.KeyRow(listOf(dev.darkdesign69.onlykeyboard.common.model.KeyDef("*"))),
                dev.darkdesign69.onlykeyboard.common.model.KeyRow(listOf(dev.darkdesign69.onlykeyboard.common.model.KeyDef("ABC"))),
                dev.darkdesign69.onlykeyboard.common.model.KeyRow(listOf(dev.darkdesign69.onlykeyboard.common.model.KeyDef("extra")))
            )
        )
        val customWithSym = dev.darkdesign69.onlykeyboard.common.model.KeyboardLayoutDef(
            id = "custom_with_sym",
            name = "Custom With Symbols",
            language = "custom",
            symbolsLayout = customSym,
            rows = emptyList()
        )
        assertEquals(customSym, customWithSym.effectiveSymbolsLayout())
        assertEquals(5, customWithSym.effectiveSymbolsLayout()!!.rows.size)
        assertTrue(customSym.isSymbolsLayout())

        // Borno Phonetic defines its own symbolsLayout with Bangla numbers in row 0 and ৳ currency symbol
        val borno = PredefinedLayouts.BengaliBorno
        org.junit.Assert.assertNotNull(borno.effectiveSymbolsLayout())
        val bornoSym = borno.effectiveSymbolsLayout()!!
        assertEquals("bn_borno_symbols", bornoSym.id)
        assertTrue(bornoSym.isSymbolsLayout())
        assertEquals(listOf("১", "২", "৩", "৪", "৫", "৬", "৭", "৮", "৯", "০"), bornoSym.rows[0].keys.map { it.label })
        assertEquals("৳", bornoSym.rows[1].keys[2].label)
        assertTrue(bornoSym.rows[1].keys[2].moreKeys.contains("$"))

        // Avro Phonetic also defines its symbolsLayout with Bangla numbers and ৳
        val avro = PredefinedLayouts.BengaliAvro
        org.junit.Assert.assertNotNull(avro.effectiveSymbolsLayout())
        val avroSym = avro.effectiveSymbolsLayout()!!
        assertEquals("bn_borno_symbols", avroSym.id)
        assertEquals(listOf("১", "২", "৩", "৪", "৫", "৬", "৭", "৮", "৯", "০"), avroSym.rows[0].keys.map { it.label })
        assertEquals("৳", avroSym.rows[1].keys[2].label)

        // Custom layouts without symbolsLayout safely return null and resolveSymbolsLayout falls back appropriately
        val customEn = dev.darkdesign69.onlykeyboard.common.model.KeyboardLayoutDef(id = "custom_en", name = "Custom En", language = "en")
        org.junit.Assert.assertNull(customEn.effectiveSymbolsLayout())
        assertEquals("symbols_1", PredefinedLayouts.resolveSymbolsLayout(customEn).id)

        val customBn = dev.darkdesign69.onlykeyboard.common.model.KeyboardLayoutDef(id = "custom_bn", name = "Custom Bn", language = "bn")
        org.junit.Assert.assertNull(customBn.effectiveSymbolsLayout())
        assertEquals("bn_borno_symbols", PredefinedLayouts.resolveSymbolsLayout(customBn).id)
    }

    @Test
    fun testJsonSerializationWithCustomSymbolsLayout() {
        val jsonString = """
            {
              "id": "test_layout",
              "name": "Test Layout",
              "language": "xx",
              "rows": [
                { "keys": [{ "label": "a" }] }
              ],
              "symbolsLayout": {
                "id": "test_symbols",
                "name": "Test Symbols",
                "rows": [
                  { "keys": [{ "label": "1" }, { "label": "2" }] },
                  { "keys": [{ "label": "@" }, { "label": "#" }] },
                  { "keys": [{ "label": "!" }, { "label": "?" }] },
                  { "keys": [{ "label": "ABC" }] },
                  { "keys": [{ "label": "extra_row" }] }
                ]
              }
            }
        """.trimIndent()

        val json = kotlinx.serialization.json.Json { ignoreUnknownKeys = true }
        val parsed = json.decodeFromString<dev.darkdesign69.onlykeyboard.common.model.KeyboardLayoutDef>(jsonString)

        assertEquals("test_layout", parsed.id)
        assertNotNull(parsed.effectiveSymbolsLayout())
        val sym = parsed.effectiveSymbolsLayout()!!
        assertEquals("test_symbols", sym.id)
        assertEquals(5, sym.rows.size)
        assertEquals("1", sym.rows[0].keys[0].label)
        assertEquals("extra_row", sym.rows[4].keys[0].label)
        assertTrue(sym.isSymbolsLayout())
    }

    @Test
    fun testDuplicateRowDetection() {
        val extraRowNums = dev.darkdesign69.onlykeyboard.common.model.LayoutExtraRow(
            id = "extra_nums",
            title = "Numbers",
            keys = listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "0").map { dev.darkdesign69.onlykeyboard.common.model.KeyDef(label = it) }
        )
        val symRowNums = dev.darkdesign69.onlykeyboard.common.model.KeyRow(
            keys = listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "0").map { dev.darkdesign69.onlykeyboard.common.model.KeyDef(label = it) }
        )
        val symRowSymbols = dev.darkdesign69.onlykeyboard.common.model.KeyRow(
            keys = listOf("@", "#", "$", "%", "&", "-", "+", "(", ")", "/").map { dev.darkdesign69.onlykeyboard.common.model.KeyDef(label = it) }
        )

        // Numbers duplicate spotted
        assertTrue(dev.darkdesign69.onlykeyboard.common.model.KeyboardLayoutDef.isDuplicateRow(extraRowNums, listOf(symRowNums, symRowSymbols)))

        // Non-duplicate Harakat row
        val harakatRow = dev.darkdesign69.onlykeyboard.common.model.LayoutExtraRow(
            id = "ar_harakat",
            title = "Harakat",
            keys = listOf("\u064e", "\u064b", "\u064f", "\u064c", "\u0650", "\u064d", "\u0652", "\u0651", "\u0640", "\u061f").map { dev.darkdesign69.onlykeyboard.common.model.KeyDef(label = it) }
        )
        org.junit.Assert.assertFalse(dev.darkdesign69.onlykeyboard.common.model.KeyboardLayoutDef.isDuplicateRow(harakatRow, listOf(symRowNums, symRowSymbols)))

        // Row ID matching existing extra row
        val existingExtra = listOf(
            dev.darkdesign69.onlykeyboard.common.model.LayoutExtraRow(
                id = "ar_harakat",
                title = "Existing Harakat",
                keys = emptyList()
            )
        )
        assertTrue(dev.darkdesign69.onlykeyboard.common.model.KeyboardLayoutDef.isDuplicateRow(harakatRow, listOf(symRowSymbols), existingExtra))
    }

    @Test
    fun testResolveExtraRowsForSymbolsCarriesOverWhenRowCountEquals() {
        val harakatRow = dev.darkdesign69.onlykeyboard.common.model.LayoutExtraRow(
            id = "ar_harakat",
            title = "Harakat",
            defaultEnabled = true,
            keys = listOf("\u064e", "\u064b", "\u064f", "\u064c", "\u0650", "\u064d", "\u0652", "\u0651", "\u0640", "\u061f").map { dev.darkdesign69.onlykeyboard.common.model.KeyDef(label = it) }
        )

        val alphaLayout = dev.darkdesign69.onlykeyboard.common.model.KeyboardLayoutDef(
            id = "ar_arabic",
            name = "Arabic",
            extraRows = listOf(harakatRow),
            rows = List(4) { dev.darkdesign69.onlykeyboard.common.model.KeyRow(keys = listOf(dev.darkdesign69.onlykeyboard.common.model.KeyDef("a"))) }
        )

        val symbolsLayout = dev.darkdesign69.onlykeyboard.common.model.KeyboardLayoutDef(
            id = "symbols",
            name = "Symbols",
            rows = List(4) { dev.darkdesign69.onlykeyboard.common.model.KeyRow(keys = listOf(dev.darkdesign69.onlykeyboard.common.model.KeyDef("1"))) }
        )

        // Alpha has 4 + 1 = 5 rows, symbols has 4 rows -> extra row moved to symbols
        val extraForSymbols = symbolsLayout.resolveExtraRowsForSymbols(alphaLayout)
        assertEquals(1, extraForSymbols.size)
        assertEquals(10, extraForSymbols[0].keys.size)
        assertEquals("\u064e", extraForSymbols[0].keys[0].label)

        // If Harakat is disabled via override, no extra row moved
        val overrides = mapOf("ar_arabic_ar_harakat" to false)
        val extraWhenDisabled = symbolsLayout.resolveExtraRowsForSymbols(alphaLayout, overrides)
        assertEquals(0, extraWhenDisabled.size)
    }

    @Test
    fun testResolveExtraRowsForSymbolsUsesCorrespondingRowWhenFound() {
        val alphaHarakat = dev.darkdesign69.onlykeyboard.common.model.LayoutExtraRow(
            id = "harakat",
            title = "Harakat",
            defaultEnabled = true,
            keys = listOf(dev.darkdesign69.onlykeyboard.common.model.KeyDef("ـَ"))
        )
        val alphaLayout = dev.darkdesign69.onlykeyboard.common.model.KeyboardLayoutDef(
            id = "ar_arabic",
            name = "Arabic",
            extraRows = listOf(alphaHarakat),
            rows = List(4) { dev.darkdesign69.onlykeyboard.common.model.KeyRow(keys = listOf(dev.darkdesign69.onlykeyboard.common.model.KeyDef("a"))) }
        )

        val symbolQuranic = dev.darkdesign69.onlykeyboard.common.model.LayoutExtraRow(
            id = "harakat",
            title = "Quranic",
            defaultEnabled = true,
            keys = listOf(dev.darkdesign69.onlykeyboard.common.model.KeyDef("ۖ"))
        )
        val symbolsLayout = dev.darkdesign69.onlykeyboard.common.model.KeyboardLayoutDef(
            id = "ar_symbols_1",
            name = "Symbols",
            extraRows = listOf(symbolQuranic),
            rows = List(4) { dev.darkdesign69.onlykeyboard.common.model.KeyRow(keys = listOf(dev.darkdesign69.onlykeyboard.common.model.KeyDef("1"))) }
        )

        // Found matching id -> uses corresponding row from symbols layout
        val extra = symbolsLayout.resolveExtraRowsForSymbols(alphaLayout)
        assertEquals(1, extra.size)
        assertEquals("ۖ", extra[0].keys[0].label)
    }

    @Test
    fun testResolveExtraRowsForSymbolsMovesExtraRowWhenNotFound() {
        val alphaExtra = dev.darkdesign69.onlykeyboard.common.model.LayoutExtraRow(
            id = "custom_feature",
            title = "Custom",
            defaultEnabled = true,
            keys = listOf(dev.darkdesign69.onlykeyboard.common.model.KeyDef("★"))
        )
        val alphaLayout = dev.darkdesign69.onlykeyboard.common.model.KeyboardLayoutDef(
            id = "custom_lang",
            name = "Custom",
            extraRows = listOf(alphaExtra),
            rows = List(4) { dev.darkdesign69.onlykeyboard.common.model.KeyRow(keys = listOf(dev.darkdesign69.onlykeyboard.common.model.KeyDef("a"))) }
        )

        val symbolsLayout = dev.darkdesign69.onlykeyboard.common.model.KeyboardLayoutDef(
            id = "custom_symbols",
            name = "Symbols",
            extraRows = emptyList(),
            rows = List(4) { dev.darkdesign69.onlykeyboard.common.model.KeyRow(keys = listOf(dev.darkdesign69.onlykeyboard.common.model.KeyDef("1"))) }
        )

        // Not found in symbol page -> moves extra row to symbol page
        val extra = symbolsLayout.resolveExtraRowsForSymbols(alphaLayout)
        assertEquals(1, extra.size)
        assertEquals("★", extra[0].keys[0].label)
    }

    @Test
    fun testRealArabicJsonRowCountMatching() {
        val jsonFile = java.io.File("../../feature/ime/src/main/assets/layouts/ar_arabic.json")
        val json = kotlinx.serialization.json.Json { ignoreUnknownKeys = true }
        val arabic = json.decodeFromString<dev.darkdesign69.onlykeyboard.common.model.KeyboardLayoutDef>(jsonFile.readText())
        val sym = arabic.effectiveSymbolsLayout()!!
        val moreSym = arabic.effectiveMoreSymbolsLayout()!!

        // Base layout has 4 rows, 1 extra row (Harakat) and 1 numberRow
        assertEquals(4, arabic.rows.size)
        assertEquals(1, arabic.extraRows.size)
        assertEquals("harakat", arabic.extraRows[0].id)
        org.junit.Assert.assertFalse(arabic.extraRows[0].defaultEnabled)
        assertNotNull(arabic.numberRow)

        // Symbols (?123) and More Symbols (=\<) have 4 core rows and matching extra row for Harakat (Quranic marks)
        assertEquals(4, sym.rows.size)
        assertEquals(1, sym.extraRows.size)
        assertEquals("harakat", sym.extraRows[0].id)
        assertEquals("ۖ", sym.extraRows[0].keys[0].label)
        assertEquals("١", sym.rows[0].keys[0].label)

        assertEquals(4, moreSym.rows.size)
        assertEquals(1, moreSym.extraRows.size)
        assertEquals("harakat", moreSym.extraRows[0].id)
        assertEquals("ۖ", moreSym.extraRows[0].keys[0].label)
        assertEquals("~", moreSym.rows[0].keys[0].label)
    }

    @Test
    fun testArabicLayoutRowCountsInAllPermutations() {
        val jsonFile = java.io.File("../../feature/ime/src/main/assets/layouts/ar_arabic.json")
        val json = kotlinx.serialization.json.Json { ignoreUnknownKeys = true }
        val arabic = json.decodeFromString<dev.darkdesign69.onlykeyboard.common.model.KeyboardLayoutDef>(jsonFile.readText())
        val sym = arabic.effectiveSymbolsLayout()!!
        val moreSym = arabic.effectiveMoreSymbolsLayout()!!

        // Helper simulating KeyboardRootView row construction
        fun buildRows(
            display: dev.darkdesign69.onlykeyboard.common.model.KeyboardLayoutDef,
            baseAlpha: dev.darkdesign69.onlykeyboard.common.model.KeyboardLayoutDef,
            showNumberRow: Boolean,
            overrides: Map<String, Boolean>
        ): List<dev.darkdesign69.onlykeyboard.common.model.KeyRow> {
            val isSymbol = display.isSymbolsLayout()
            val isMoreSymbols = display.isMoreSymbolsLayout()
            val numRow: List<dev.darkdesign69.onlykeyboard.common.model.KeyRow> = if (showNumberRow && !isMoreSymbols) {
                listOf(display.numberRow ?: baseAlpha.numberRow ?: PredefinedLayouts.createNumberRow(baseAlpha.language))
            } else {
                emptyList()
            }
            val extraRows: List<dev.darkdesign69.onlykeyboard.common.model.KeyRow> = if (isSymbol) {
                display.resolveExtraRowsForSymbols(baseAlpha, overrides)
            } else {
                display.extraRows.filter { extra ->
                    overrides["${display.id}_${extra.id}"] ?: extra.defaultEnabled
                }.map { dev.darkdesign69.onlykeyboard.common.model.KeyRow(it.keys) }
            }
            val coreRows: List<dev.darkdesign69.onlykeyboard.common.model.KeyRow> = if (isSymbol) {
                display.resolveCoreRowsForSymbols(showNumberRow)
            } else {
                display.rows
            }
            return numRow + extraRows + coreRows
        }

        // Permutation 1: Both number row and harakat enabled
        val p1Overrides = mapOf("ar_arabic_harakat" to true)
        val p1Alpha = buildRows(arabic, arabic, showNumberRow = true, p1Overrides)
        val p1Sym = buildRows(sym, arabic, showNumberRow = true, p1Overrides)
        val p1More = buildRows(moreSym, arabic, showNumberRow = true, p1Overrides)
        assertEquals(6, p1Alpha.size)
        assertEquals(6, p1Sym.size)
        assertEquals(6, p1More.size)
        assertEquals(p1Alpha.size, p1Sym.size)
        assertEquals(p1Alpha.size, p1More.size)

        // Permutation 2: Number row enabled, harakat disabled
        val p2Overrides = mapOf("ar_arabic_harakat" to false)
        val p2Alpha = buildRows(arabic, arabic, showNumberRow = true, p2Overrides)
        val p2Sym = buildRows(sym, arabic, showNumberRow = true, p2Overrides)
        val p2More = buildRows(moreSym, arabic, showNumberRow = true, p2Overrides)
        assertEquals(5, p2Alpha.size)
        assertEquals(5, p2Sym.size)
        assertEquals(5, p2More.size)
        assertEquals(p2Alpha.size, p2Sym.size)
        assertEquals(p2Alpha.size, p2More.size)

        // Permutation 3: Number row disabled, harakat enabled
        val p3Overrides = mapOf("ar_arabic_harakat" to true)
        val p3Alpha = buildRows(arabic, arabic, showNumberRow = false, p3Overrides)
        val p3Sym = buildRows(sym, arabic, showNumberRow = false, p3Overrides)
        val p3More = buildRows(moreSym, arabic, showNumberRow = false, p3Overrides)
        assertEquals(5, p3Alpha.size)
        assertEquals(5, p3Sym.size)
        assertEquals(5, p3More.size)
        assertEquals(p3Alpha.size, p3Sym.size)
        assertEquals(p3Alpha.size, p3More.size)

        // Permutation 4: Both number row and harakat disabled
        val p4Overrides = mapOf("ar_arabic_harakat" to false)
        val p4Alpha = buildRows(arabic, arabic, showNumberRow = false, p4Overrides)
        val p4Sym = buildRows(sym, arabic, showNumberRow = false, p4Overrides)
        val p4More = buildRows(moreSym, arabic, showNumberRow = false, p4Overrides)
        assertEquals(4, p4Alpha.size)
        assertEquals(4, p4Sym.size)
        assertEquals(4, p4More.size)
        assertEquals(p4Alpha.size, p4Sym.size)
        assertEquals(p4Alpha.size, p4More.size)
    }

    @Test
    fun testAllPredefinedLayoutsRowCountsMatchAcrossAllStates() {
        fun buildRows(
            display: dev.darkdesign69.onlykeyboard.common.model.KeyboardLayoutDef,
            baseAlpha: dev.darkdesign69.onlykeyboard.common.model.KeyboardLayoutDef,
            showNumberRow: Boolean
        ): List<dev.darkdesign69.onlykeyboard.common.model.KeyRow> {
            val isSymbol = display.isSymbolsLayout()
            val isMoreSymbols = display.isMoreSymbolsLayout()
            val numRow: List<dev.darkdesign69.onlykeyboard.common.model.KeyRow> = if (showNumberRow && !isMoreSymbols) {
                listOf(display.numberRow ?: baseAlpha.numberRow ?: PredefinedLayouts.createNumberRow(baseAlpha.language))
            } else {
                emptyList()
            }
            val extraRows: List<dev.darkdesign69.onlykeyboard.common.model.KeyRow> = if (isSymbol) {
                display.resolveExtraRowsForSymbols(baseAlpha, emptyMap())
            } else {
                display.extraRows.filter { it.defaultEnabled }.map { dev.darkdesign69.onlykeyboard.common.model.KeyRow(it.keys) }
            }
            val coreRows: List<dev.darkdesign69.onlykeyboard.common.model.KeyRow> = if (isSymbol) {
                display.resolveCoreRowsForSymbols(showNumberRow)
            } else {
                display.rows
            }
            return numRow + extraRows + coreRows
        }

        for (layout in PredefinedLayouts.allPredefined) {
            val is6Row = layout.rows.size >= 6
            val expectedWithNum = if (is6Row) 7 else 5
            val expectedNoNum = if (is6Row) 6 else 4

            val sym = layout.effectiveSymbolsLayout() ?: PredefinedLayouts.Symbols
            val moreSym = layout.effectiveMoreSymbolsLayout() ?: PredefinedLayouts.SymbolsMore

            // 1. With number row enabled: ABC, ?123, and =< must match
            val rowsAlphaWithNum = buildRows(layout, layout, showNumberRow = true)
            val rowsSymWithNum = buildRows(sym, layout, showNumberRow = true)
            val rowsMoreWithNum = buildRows(moreSym, layout, showNumberRow = true)

            assertEquals("${layout.id} ABC row count with number row must be $expectedWithNum", expectedWithNum, rowsAlphaWithNum.size)
            assertEquals("${layout.id} Symbols (?123) row count with number row must be $expectedWithNum", expectedWithNum, rowsSymWithNum.size)
            assertEquals("${layout.id} More Symbols (=<) row count with number row must be $expectedWithNum", expectedWithNum, rowsMoreWithNum.size)
            assertEquals("${layout.id} row counts must match across ABC and ?123", rowsAlphaWithNum.size, rowsSymWithNum.size)
            assertEquals("${layout.id} row counts must match across ABC and =<", rowsAlphaWithNum.size, rowsMoreWithNum.size)

            // 2. With number row disabled: ABC, ?123, and =< must match
            val rowsAlphaNoNum = buildRows(layout, layout, showNumberRow = false)
            val rowsSymNoNum = buildRows(sym, layout, showNumberRow = false)
            val rowsMoreNoNum = buildRows(moreSym, layout, showNumberRow = false)

            assertEquals("${layout.id} ABC row count without number row must be $expectedNoNum", expectedNoNum, rowsAlphaNoNum.size)
            assertEquals("${layout.id} Symbols (?123) row count without number row must be $expectedNoNum", expectedNoNum, rowsSymNoNum.size)
            assertEquals("${layout.id} More Symbols (=<) row count without number row must be $expectedNoNum", expectedNoNum, rowsMoreNoNum.size)
            assertEquals("${layout.id} row counts must match across ABC and ?123", rowsAlphaNoNum.size, rowsSymNoNum.size)
            assertEquals("${layout.id} row counts must match across ABC and =<", rowsAlphaNoNum.size, rowsMoreNoNum.size)
        }
    }

    @Test
    fun testResolveCoreRowsForSymbols() {
        assertEquals(4, PredefinedLayouts.Symbols.resolveCoreRowsForSymbols(showNumberRow = true).size)
        assertEquals(4, PredefinedLayouts.Symbols.resolveCoreRowsForSymbols(showNumberRow = false).size)
        assertEquals(5, PredefinedLayouts.SymbolsMore.resolveCoreRowsForSymbols(showNumberRow = true).size)
        assertEquals(4, PredefinedLayouts.SymbolsMore.resolveCoreRowsForSymbols(showNumberRow = false).size)

        assertEquals(4, PredefinedLayouts.SymbolsWithNumberRow.resolveCoreRowsForSymbols(showNumberRow = true).size)
        assertEquals(4, PredefinedLayouts.SymbolsWithNumberRow.resolveCoreRowsForSymbols(showNumberRow = false).size)
        assertEquals(5, PredefinedLayouts.SymbolsMoreWithNumberRow.resolveCoreRowsForSymbols(showNumberRow = true).size)
        assertEquals(4, PredefinedLayouts.SymbolsMoreWithNumberRow.resolveCoreRowsForSymbols(showNumberRow = false).size)

        // SymbolsMore top row preservation (must remain ~ and not replaced with 1)
        val moreWithNum = PredefinedLayouts.SymbolsMore.resolveCoreRowsForSymbols(showNumberRow = true)
        assertEquals("~", moreWithNum[0].keys[0].label)
        assertEquals("≠", moreWithNum[1].keys[0].label)

        // Borno Easy ?123 resolution
        val bornoEasyWithNum = PredefinedLayouts.BengaliBornoEasySymbols.resolveCoreRowsForSymbols(showNumberRow = true)
        assertEquals(6, bornoEasyWithNum.size)
        assertEquals("1", bornoEasyWithNum[0].keys[0].label)
        assertEquals("÷", bornoEasyWithNum[1].keys[0].label)
        assertEquals("!", bornoEasyWithNum[2].keys[0].label)

        // Ensure row 1 symbols are not duplicated in rows 2, 3, 4
        val insertedRowLabels = bornoEasyWithNum[1].keys.map { it.label }.toSet()
        val subsequentLabels = (bornoEasyWithNum[2].keys + bornoEasyWithNum[3].keys + bornoEasyWithNum[4].keys).map { it.label }.toSet()
        assertTrue(insertedRowLabels.intersect(subsequentLabels).isEmpty())

        val bornoEasyNoNum = PredefinedLayouts.BengaliBornoEasySymbols.resolveCoreRowsForSymbols(showNumberRow = false)
        assertEquals(6, bornoEasyNoNum.size)
        assertEquals("১", bornoEasyNoNum[0].keys[0].label)
        assertEquals("1", bornoEasyNoNum[1].keys[0].label)
    }

    @Test
    fun testNumberPadExtendedLayout() {
        val layout = PredefinedLayouts.fromId("num_extended")
        assertEquals("num_extended", layout.id)
        assertEquals(4, layout.rows.size)

        // Rows 0-2 must each sum to 10.0f
        for (r in 0..2) {
            val keys = layout.rows[r].keys
            assertEquals(5, keys.size)
            val sum = keys.map { it.widthWeight }.sum()
            assertEquals(10.0f, sum, 0.01f)
        }

        // Row 3 (bottom row) must sum to 10.0f
        val r3 = layout.rows[3].keys
        assertEquals(6, r3.size)
        val r3Sum = r3.map { it.widthWeight }.sum()
        assertEquals(10.0f, r3Sum, 0.01f)

        // Check key types and labels
        assertEquals("ABC", r3[0].label)
        assertEquals(KeyType.SYMBOLS, r3[0].type)
        assertEquals(KeyType.SPACE, r3[1].type)
        assertEquals("0", r3[2].label)
        assertEquals(".", r3[3].label)
        assertEquals(",", r3[4].label)
        assertEquals(KeyType.ACTION, r3[5].type)

        // Check delete key in row 2
        assertEquals(KeyType.DELETE, layout.rows[2].keys[4].type)
    }

    @Test
    fun testNumberPadNormalAndVariants() {
        // Normal Numpad
        val normal = PredefinedLayouts.fromId("num_normal")
        assertEquals("num_normal", normal.id)
        assertEquals(4, normal.rows.size)
        for (row in normal.rows) {
            assertEquals(4, row.keys.size)
            assertEquals(4.0f, row.keys.map { it.widthWeight }.sum(), 0.01f)
        }

        // DateTime Numpad
        val dt = PredefinedLayouts.fromId("num_datetime")
        assertEquals("num_datetime", dt.id)
        assertEquals(4, dt.rows.size)
        assertEquals("/", dt.rows[3].keys[0].label)
        assertEquals(":", dt.rows[3].keys[2].label)

        // Phone Numpad
        val phone = PredefinedLayouts.fromId("num_phone")
        assertEquals("num_phone", phone.id)
        assertEquals(4, phone.rows.size)
        assertEquals("*#", phone.rows[3].keys[0].label)
        assertEquals(KeyType.SYMBOLS, phone.rows[3].keys[0].type)
        assertEquals("ABC", phone.rows[0].keys[1].shiftedLabel)
        assertEquals("WXYZ", phone.rows[2].keys[2].shiftedLabel)

        // Password PIN Pad (Centered with side padding)
        val pin = PredefinedLayouts.fromId("num_password")
        assertEquals("num_password", pin.id)
        assertEquals(4, pin.rows.size)
        for (row in pin.rows) {
            assertEquals(3, row.keys.size)
            assertEquals(0.375f, row.startPaddingWeight, 0.01f)
            assertEquals(0.375f, row.endPaddingWeight, 0.01f)
        }
        assertEquals(KeyType.DELETE, pin.rows[3].keys[0].type)
        assertEquals("0", pin.rows[3].keys[1].label)
        assertEquals(KeyType.ACTION, pin.rows[3].keys[2].type)
    }

    @Test
    fun testNumberLayoutRoutingAndHelpers() {
        assertTrue(PredefinedLayouts.isNumberLayout("num_extended"))
        assertTrue(PredefinedLayouts.isNumberLayout("num_normal"))
        assertTrue(PredefinedLayouts.isNumberLayout("num_datetime"))
        assertTrue(PredefinedLayouts.isNumberLayout("num_phone"))
        assertTrue(PredefinedLayouts.isNumberLayout("num_password"))
        org.junit.Assert.assertFalse(PredefinedLayouts.isNumberLayout("en_qwerty"))
        org.junit.Assert.assertFalse(PredefinedLayouts.isNumberLayout("bn_borno"))

        // Resolver tests
        assertEquals(
            "num_phone",
            PredefinedLayouts.resolveNumberLayout(android.text.InputType.TYPE_CLASS_PHONE, 0)?.id
        )
        assertEquals(
            "num_datetime",
            PredefinedLayouts.resolveNumberLayout(android.text.InputType.TYPE_CLASS_DATETIME, 0)?.id
        )
        assertEquals(
            "num_normal",
            PredefinedLayouts.resolveNumberLayout(android.text.InputType.TYPE_CLASS_NUMBER, 0)?.id
        )
        assertEquals(
            "num_password",
            PredefinedLayouts.resolveNumberLayout(
                android.text.InputType.TYPE_CLASS_NUMBER,
                android.text.InputType.TYPE_NUMBER_VARIATION_PASSWORD
            )?.id
        )
        org.junit.Assert.assertNull(
            PredefinedLayouts.resolveNumberLayout(android.text.InputType.TYPE_CLASS_TEXT, 0)
        )
    }

    @Test
    fun testBornoMathJsonLayoutValidation() {
        val jsonFile = java.io.File("../../feature/ime/src/main/assets/layouts/borno_math.json")
        assertTrue("borno_math.json must exist in assets/layouts/", jsonFile.exists())
        val json = kotlinx.serialization.json.Json { ignoreUnknownKeys = true }
        val mathLayout = json.decodeFromString<dev.darkdesign69.onlykeyboard.common.model.KeyboardLayoutDef>(jsonFile.readText())

        assertEquals("borno_math", mathLayout.id)
        assertEquals("Borno Math", mathLayout.name)
        assertEquals("Borno Math", mathLayout.displayName)
        assertEquals("English layout with mathematical symbols", mathLayout.description)
        assertEquals("en", mathLayout.language)
        assertEquals("LTR", mathLayout.direction)
        assertEquals("qwerty", mathLayout.gestureMode)
        assertTrue(mathLayout.isQwertyBased())

        // Validate number row
        val numRow = mathLayout.numberRow
        assertNotNull("numberRow must be defined", numRow)
        assertEquals(10, numRow!!.keys.size)
        val superscripts = listOf("¹", "²", "³", "⁴", "⁵", "⁶", "⁷", "⁸", "⁹", "⁰")
        for (i in 0 until 10) {
            assertEquals(superscripts[i], numRow.keys[i].flickUp)
        }
        assertEquals(listOf("¹", "₁", "½", "⅓", "¼", "⅛"), numRow.keys[0].moreKeys)
        assertEquals(listOf("²", "₂", "⅔"), numRow.keys[1].moreKeys)
        assertEquals(listOf("³", "₃", "¾", "⅜"), numRow.keys[2].moreKeys)
        assertEquals(listOf("⁴", "₄"), numRow.keys[3].moreKeys)
        assertEquals(listOf("⁵", "₅", "⅝"), numRow.keys[4].moreKeys)
        assertEquals(listOf("⁶", "₆"), numRow.keys[5].moreKeys)
        assertEquals(listOf("⁷", "₇", "⅞"), numRow.keys[6].moreKeys)
        assertEquals(listOf("⁸", "₈"), numRow.keys[7].moreKeys)
        assertEquals(listOf("⁹", "₉"), numRow.keys[8].moreKeys)
        assertEquals(listOf("⁰", "₀", "ⁿ", "∅"), numRow.keys[9].moreKeys)

        // Validate 4 main rows
        assertEquals(4, mathLayout.rows.size)

        // Row 0: q..p with math flick-ups and exact morekeys
        val r0 = mathLayout.rows[0].keys
        assertEquals(10, r0.size)
        val r0FlickUps = listOf("θ", "∧", "ε", "ρ", "τ", "ψ", "∪", "∫", "ω", "π")
        for (i in 0 until 10) {
            assertEquals(r0FlickUps[i], r0[i].flickUp)
            assertEquals(1.0f, r0[i].widthWeight, 0.01f)
        }
        assertEquals(listOf("θ", "Θ", "¹", "₁"), r0[0].moreKeys)
        assertEquals(listOf("∧", "ʷ", "²", "₂"), r0[1].moreKeys)
        assertEquals(listOf("ε", "∃", "ᵉ", "ₑ", "³", "₃"), r0[2].moreKeys)
        assertEquals(listOf("ρ", "ʳ", "ᵣ", "⁴", "₄"), r0[3].moreKeys)
        assertEquals(listOf("τ", "×", "tan", "ᵗ", "ₜ", "⁵", "₅"), r0[4].moreKeys)
        assertEquals(listOf("ψ", "ʸ", "⁶", "₆"), r0[5].moreKeys)
        assertEquals(listOf("∪", "ᵘ", "ᵤ", "⁷", "₇"), r0[6].moreKeys)
        assertEquals(listOf("∫", "∞", "∈", "ⁱ", "ᵢ", "⁸", "₈"), r0[7].moreKeys)
        assertEquals(listOf("ω", "Ω", "∘", "ᵒ", "ₒ", "⁹", "₉"), r0[8].moreKeys)
        assertEquals(listOf("π", "∂", "∏", "ᵖ", "ₚ", "⁰", "₀"), r0[9].moreKeys)

        // Row 1: a..l with math flick-ups and 0.5 side padding
        val r1 = mathLayout.rows[1]
        assertEquals(9, r1.keys.size)
        assertEquals(0.5f, r1.startPaddingWeight, 0.01f)
        assertEquals(0.5f, r1.endPaddingWeight, 0.01f)
        val r1FlickUps = listOf("α", "σ", "δ", "φ", "γ", "ℏ", "ȷ", "κ", "λ")
        for (i in 0 until 9) {
            assertEquals(r1FlickUps[i], r1.keys[i].flickUp)
            assertEquals(1.0f, r1.keys[i].widthWeight, 0.01f)
        }
        val r1TotalWidth = r1.startPaddingWeight + r1.keys.sumOf { it.widthWeight.toDouble() } + r1.endPaddingWeight
        assertEquals(10.0, r1TotalWidth, 0.01)

        // Row 2: Shift + z..m + Delete
        val r2 = mathLayout.rows[2].keys
        assertEquals(9, r2.size)
        assertEquals(KeyType.SHIFT, r2[0].type)
        assertEquals(1.5f, r2[0].widthWeight, 0.01f)
        val r2FlickUps = listOf("ζ", "×", "cos", "∨", "β", "∇", "μ")
        for (i in 0 until 7) {
            assertEquals(r2FlickUps[i], r2[i + 1].flickUp)
            assertEquals(1.0f, r2[i + 1].widthWeight, 0.01f)
        }
        assertEquals(KeyType.DELETE, r2[8].type)
        assertEquals(1.5f, r2[8].widthWeight, 0.01f)
        val r2TotalWidth = r2.sumOf { it.widthWeight.toDouble() }
        assertEquals(10.0, r2TotalWidth, 0.01)

        // Row 3: ?123, comma, globe, space (4.0), period, enter
        val r3 = mathLayout.rows[3].keys
        assertEquals(6, r3.size)
        assertEquals(KeyType.SYMBOLS, r3[0].type)
        assertEquals(1.5f, r3[0].widthWeight, 0.01f)
        assertEquals(listOf("ACTION_SETTINGS", "ACTION_ONE_HANDED"), r3[1].moreKeys)
        assertEquals(KeyType.SWITCH_LANGUAGE, r3[2].type)
        assertEquals(KeyType.SPACE, r3[3].type)
        assertEquals(4.0f, r3[3].widthWeight, 0.01f)
        assertEquals(".", r3[4].label)
        assertEquals(8, r3[4].moreKeysColumns)
        assertEquals(
            listOf(",", "?", "!", "#", ")", "(", "/", ";", "'", "@", ":", "-", "\"", "+", "%", "&"),
            r3[4].moreKeys
        )
        assertEquals(KeyType.ACTION, r3[5].type)
        assertEquals(1.5f, r3[5].widthWeight, 0.01f)
        assertEquals(listOf("ACTION_EMOJI"), r3[5].moreKeys)
        val r3TotalWidth = r3.sumOf { it.widthWeight.toDouble() }
        assertEquals(10.0, r3TotalWidth, 0.01)

        // Validate symbolsLayout (?123)
        val sym = mathLayout.effectiveSymbolsLayout()
        assertNotNull("symbolsLayout must be present", sym)
        assertEquals("borno_math_symbols", sym!!.id)
        assertTrue(sym.isSymbolsLayout())
        assertEquals(4, sym.rows.size)
        assertEquals(10, sym.rows[0].keys.size)
        assertEquals(listOf("¹", "½"), sym.rows[0].keys[0].moreKeys)
        assertEquals(listOf("²"), sym.rows[0].keys[1].moreKeys)
        assertEquals(listOf("³", "¾"), sym.rows[0].keys[2].moreKeys)
        assertEquals(listOf("⁴", "¼"), sym.rows[0].keys[3].moreKeys)
        assertEquals(listOf("⁵"), sym.rows[0].keys[4].moreKeys)
        assertEquals(listOf("⁶"), sym.rows[0].keys[5].moreKeys)
        assertEquals(listOf("⁷"), sym.rows[0].keys[6].moreKeys)
        assertEquals(listOf("⁸"), sym.rows[0].keys[7].moreKeys)
        assertEquals(listOf("⁹"), sym.rows[0].keys[8].moreKeys)
        assertEquals(listOf("⁰"), sym.rows[0].keys[9].moreKeys)
        assertEquals("±", sym.rows[1].keys[0].label)
        assertEquals(listOf("+", "⁺", "⁻"), sym.rows[1].keys[0].moreKeys)
        assertEquals(listOf("*"), sym.rows[1].keys[1].moreKeys)
        assertEquals(listOf("/"), sym.rows[1].keys[2].moreKeys)
        assertEquals(listOf("~"), sym.rows[1].keys[3].moreKeys)
        assertEquals(listOf("≠", "⁼"), sym.rows[1].keys[4].moreKeys)
        assertEquals(listOf("<"), sym.rows[1].keys[5].moreKeys)
        assertEquals(listOf(">"), sym.rows[1].keys[6].moreKeys)
        assertTrue(sym.rows[1].keys[7].moreKeys.isEmpty())
        assertTrue(sym.rows[1].keys[8].moreKeys.isEmpty())
        assertEquals(listOf("∬", "∭", "∮"), sym.rows[1].keys[9].moreKeys)
        assertEquals("=\\<", sym.rows[2].keys[0].label)
        assertEquals(KeyType.SYMBOLS, sym.rows[2].keys[0].type)
        assertEquals("∇", sym.rows[2].keys[1].label)
        assertEquals(KeyType.DELETE, sym.rows[2].keys[8].type)
        assertEquals("ABC", sym.rows[3].keys[0].label)
        assertEquals(KeyType.SPACE, sym.rows[3].keys[3].type)

        // Validate moreSymbolsLayout (=\<)
        val moreSym = mathLayout.effectiveMoreSymbolsLayout()
        assertNotNull("moreSymbolsLayout must be present", moreSym)
        assertEquals("borno_math_symbols_2", moreSym!!.id)
        assertTrue(moreSym.isSymbolsLayout())
        assertEquals(4, moreSym.rows.size)
        assertEquals("∈", moreSym.rows[0].keys[0].label)
        assertEquals("∅", moreSym.rows[1].keys[0].label)
        assertEquals(0.5f, moreSym.rows[1].startPaddingWeight, 0.01f)
        assertEquals("?123", moreSym.rows[2].keys[0].label)
        assertEquals(KeyType.SYMBOLS, moreSym.rows[2].keys[0].type)
        assertEquals("∯", moreSym.rows[2].keys[1].label)
        assertEquals(KeyType.DELETE, moreSym.rows[2].keys[8].type)
        assertEquals("ABC", moreSym.rows[3].keys[0].label)
        assertEquals(listOf("‹", "≤", "«"), moreSym.rows[3].keys[2].moreKeys)
        assertEquals(listOf("›", "≥", "»"), moreSym.rows[3].keys[4].moreKeys)
    }

    @Test
    fun testKhiproJsonAssetIntegrity() {
        val candidates = listOf(
            java.io.File("../../assets-src/language-packs/khipro/layouts/bn_khipro_classic.json"),
            java.io.File("assets-src/language-packs/khipro/layouts/bn_khipro_classic.json"),
            java.io.File("../assets-src/language-packs/khipro/layouts/bn_khipro_classic.json"),
        )
        val jsonFile = candidates.firstOrNull { it.exists() }
        assertNotNull("bn_khipro_classic.json must exist in assets-src/language-packs/khipro/layouts/", jsonFile)

        val json = kotlinx.serialization.json.Json { ignoreUnknownKeys = true }
        val layout = json.decodeFromString<dev.darkdesign69.onlykeyboard.common.model.KeyboardLayoutDef>(jsonFile!!.readText())

        assertEquals("bn_khipro_classic", layout.id)
        assertEquals("Khipro Classic", layout.name)
        assertEquals("Khipro Classic", layout.displayName)
        assertEquals("bn", layout.language)
        assertEquals("LTR", layout.direction)
        assertEquals("m17n", layout.processor)
        assertEquals("bn-khipro.classic.mim", layout.rules)
        assertEquals("bn_borno", layout.gestureMode)
        assertEquals("Compositional Layout", layout.description)
        assertEquals(listOf("NoAutoCapitalization", "NoRemoveSpaceBeforePunctuation"), layout.flags)
        assertTrue("khipro must have NoAutoCapitalization flag", layout.hasFlag("NoAutoCapitalization"))
        assertTrue("khipro.noAutoCapitalization must be true", layout.noAutoCapitalization)
        assertTrue("khipro must have NoRemoveSpaceBeforePunctuation flag", layout.hasFlag("NoRemoveSpaceBeforePunctuation"))
        assertTrue("khipro.noRemoveSpaceBeforePunctuation must be true", layout.noRemoveSpaceBeforePunctuation)
        assertEquals(listOf(",", "।"), layout.extraCompositionChars)
        assertTrue(layout.isExtraCompositionChar(","))
        assertTrue(layout.isExtraCompositionChar("।"))
        assertFalse(layout.isExtraCompositionChar("a"))
        assertNotNull("khipro numberRow must be defined", layout.numberRow)
        assertEquals(listOf("১", "২", "৩", "৪", "৫", "৬", "৭", "৮", "৯", "০"), layout.numberRow!!.keys.map { it.label })
        assertTrue(layout.isQwertyBased())

        // Verify exact EN QWERTY rows
        val row1 = layout.rows[0].keys.map { it.label }
        assertEquals(listOf("q", "w", "e", "r", "t", "y", "u", "i", "o", "p"), row1)

        val row2 = layout.rows[1].keys.map { it.label }
        assertEquals(listOf("a", "s", "d", "f", "g", "h", "j", "k", "l"), row2)

        // Verify row 3 (primary page) is shift-key-less with '/' replacing Shift
        val slashKey = layout.rows[2].keys[0]
        assertEquals("/", slashKey.label)
        assertTrue(layout.rows[2].keys.none { it.type == dev.darkdesign69.onlykeyboard.common.model.KeyType.SHIFT })
        assertFalse("khipro must not have shift key", layout.hasShiftKey())
        val row3Chars = layout.rows[2].keys.filter { it.type == dev.darkdesign69.onlykeyboard.common.model.KeyType.CHARACTER }.map { it.label }
        assertEquals(listOf("/", "z", "x", "c", "v", "b", "n", "m"), row3Chars)

        // Verify bottom row has ';' and '।' (dari) to the right of spacebar
        val spaceIdx = layout.rows[3].keys.indexOfFirst { it.type == dev.darkdesign69.onlykeyboard.common.model.KeyType.SPACE }
        assertTrue("Space key must exist in bottom row", spaceIdx >= 0)
        val rightKeys = layout.rows[3].keys.drop(spaceIdx + 1)
        val semicolonKey = rightKeys.find { it.label == ";" }
        assertNotNull("; key must exist to the right of space", semicolonKey)
        val dariKey = rightKeys.find { it.label == "।" }
        assertNotNull("Dari key (।) must exist to the right of space", dariKey)
        assertEquals(9, dariKey!!.moreKeysColumns)
        val expectedDariMoreKeys = listOf(".", ",", "?", "!", "#", ")", "(", "/", ";", "'", "@", ":", "-", "\"", "+", "%", "&")
        assertEquals(expectedDariMoreKeys, dariKey.moreKeys)

        // Verify full symbolsLayout as QWERTY
        val sym = layout.symbolsLayout
        assertNotNull("symbolsLayout must be present", sym)
        assertEquals("symbols_1", sym!!.id)
        assertEquals(4, sym.rows.size)
        assertEquals(listOf("১", "২", "৩", "৪", "৫", "৬", "৭", "৮", "৯", "০"), sym.rows[0].keys.map { it.label })

        // Verify full moreSymbolsLayout as QWERTY
        val moreSym = layout.moreSymbolsLayout
        assertNotNull("moreSymbolsLayout must be present", moreSym)
        assertEquals("symbols_2", moreSym!!.id)
        assertEquals(4, moreSym.rows.size)
        assertEquals(listOf("~", "`", "|", "•", "√", "π", "÷", "×", "¶", "∆"), moreSym.rows[0].keys.map { it.label })

        // Verify Khipro Dark layout
        val darkCandidates = listOf(
            java.io.File("../../assets-src/language-packs/khipro/layouts/bn_khipro_dark.json"),
            java.io.File("assets-src/language-packs/khipro/layouts/bn_khipro_dark.json"),
            java.io.File("../assets-src/language-packs/khipro/layouts/bn_khipro_dark.json"),
        )
        val darkJsonFile = darkCandidates.firstOrNull { it.exists() }
        assertNotNull("bn_khipro_dark.json must exist in assets-src/language-packs/khipro/layouts/", darkJsonFile)
        val darkLayout = json.decodeFromString<dev.darkdesign69.onlykeyboard.common.model.KeyboardLayoutDef>(darkJsonFile!!.readText())
        assertEquals("bn_khipro_dark", darkLayout.id)
        assertEquals("Khipro Dark", darkLayout.name)
        assertEquals("Khipro Dark", darkLayout.displayName)
        assertEquals("bn-khipro-dark.mim", darkLayout.rules)

        // Verify rules files exist in extension pack source
        val rulesCandidates = listOf(
            java.io.File("../../assets-src/language-packs/khipro/rules/bn-khipro.classic.mim"),
            java.io.File("assets-src/language-packs/khipro/rules/bn-khipro.classic.mim"),
            java.io.File("../assets-src/language-packs/khipro/rules/bn-khipro.classic.mim"),
        )
        val rulesFile = rulesCandidates.firstOrNull { it.exists() }
        assertNotNull("bn-khipro.classic.mim must exist in pack rules", rulesFile)
        assertTrue("classic rules file must not be empty", rulesFile!!.length() > 0)

        val darkRulesCandidates = listOf(
            java.io.File("../../assets-src/language-packs/khipro/rules/bn-khipro-dark.mim"),
            java.io.File("assets-src/language-packs/khipro/rules/bn-khipro-dark.mim"),
            java.io.File("../assets-src/language-packs/khipro/rules/bn-khipro-dark.mim"),
        )
        val darkRulesFile = darkRulesCandidates.firstOrNull { it.exists() }
        assertNotNull("bn-khipro-dark.mim must exist in pack rules", darkRulesFile)
        assertTrue("dark rules file must not be empty", darkRulesFile!!.length() > 0)

        // Verify bundled .bornolang extension archive in APK assets
        val extensionCandidates = listOf(
            java.io.File("../../feature/ime/src/main/assets/extensions/khipro.bornolang"),
            java.io.File("feature/ime/src/main/assets/extensions/khipro.bornolang"),
            java.io.File("../feature/ime/src/main/assets/extensions/khipro.bornolang"),
        )
        val extFile = extensionCandidates.firstOrNull { it.exists() }
        assertNotNull("khipro.bornolang must be bundled in APK assets/extensions/", extFile)

        java.util.zip.ZipFile(extFile!!).use { zip ->
            assertNotNull("pack.json must exist in khipro.bornolang", zip.getEntry("pack.json"))
            assertNotNull("bn_khipro_classic.json must exist in khipro.bornolang", zip.getEntry("layouts/bn_khipro_classic.json"))
            assertNotNull("bn_khipro_dark.json must exist in khipro.bornolang", zip.getEntry("layouts/bn_khipro_dark.json"))
            assertNotNull("bn-khipro.classic.mim must exist in khipro.bornolang", zip.getEntry("rules/bn-khipro.classic.mim"))
            assertNotNull("bn-khipro-dark.mim must exist in khipro.bornolang", zip.getEntry("rules/bn-khipro-dark.mim"))
            val entries = zip.entries().asSequence().map { it.name }.toList()
            assertFalse("khipro.bornolang must not contain a dictionary", entries.any { it.startsWith("dictionaries/") || it.endsWith(".dict") })
        }
    }

    @Test
    fun testBnNational2004JsonAssetIntegrity() {
        val candidates = listOf(
            java.io.File("../../feature/ime/src/main/assets/layouts/bn_national_2004.json"),
            java.io.File("feature/ime/src/main/assets/layouts/bn_national_2004.json"),
            java.io.File("../feature/ime/src/main/assets/layouts/bn_national_2004.json"),
        )
        val jsonFile = candidates.firstOrNull { it.exists() }
        assertNotNull("bn_national_2004.json must exist in assets/layouts/", jsonFile)

        val json = kotlinx.serialization.json.Json { ignoreUnknownKeys = true }
        val layout = json.decodeFromString<dev.darkdesign69.onlykeyboard.common.model.KeyboardLayoutDef>(jsonFile!!.readText())

        assertEquals("bn_national_2004", layout.id)
        assertEquals("জাতীয়", layout.name)
        assertEquals("জাতীয়", layout.displayName)
        assertEquals("bn", layout.language)
        assertEquals("LTR", layout.direction)
        assertEquals("bn_fixed", layout.processor)
        assertEquals("National Keyboard Layout: BDS 1738:2004", layout.description)
        assertEquals("NoAutoCapitalization", layout.flag)
    }

    @Test
    fun testEnQwertyJsonAssetValidation() {
        val candidates = listOf(
            java.io.File("../../assets-src/layouts/en_qwerty.json"),
            java.io.File("assets-src/layouts/en_qwerty.json"),
            java.io.File("../assets-src/layouts/en_qwerty.json")
        )
        val jsonFile = candidates.firstOrNull { it.exists() }
        assertNotNull("en_qwerty.json must exist in assets-src/layouts/", jsonFile)

        val json = kotlinx.serialization.json.Json { ignoreUnknownKeys = true }
        val layout = json.decodeFromString<dev.darkdesign69.onlykeyboard.common.model.KeyboardLayoutDef>(jsonFile!!.readText())

        assertEquals("en_qwerty", layout.id)
        assertEquals("English (QWERTY)", layout.name)
        assertEquals("en", layout.language)
        assertEquals("LTR", layout.direction)
        assertEquals("qwerty", layout.gestureMode)
        assertEquals("Standard Latin layout with gesture typing", layout.description)
        assertTrue(layout.isQwertyBased())

        assertNotNull("numberRow must be defined", layout.numberRow)
        assertEquals(10, layout.numberRow!!.keys.size)
        assertEquals(listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "0"), layout.numberRow!!.keys.map { it.label })

        assertEquals(4, layout.rows.size)
        assertEquals(listOf("q", "w", "e", "r", "t", "y", "u", "i", "o", "p"), layout.rows[0].keys.map { it.label })
        assertNotNull("symbolsLayout must be defined", layout.symbolsLayout)
        assertNotNull("moreSymbolsLayout must be defined", layout.moreSymbolsLayout)
    }

    @Test
    fun testPredefinedEnglishQwertyProperties() {
        val layout = PredefinedLayouts.EnglishQwerty
        assertEquals("en_qwerty", layout.id)
        assertEquals("English (QWERTY)", layout.name)
        assertEquals("English", layout.displayName)
        assertEquals("en", layout.language)
        assertEquals("LTR", layout.direction)
        assertEquals("qwerty", layout.gestureMode)
        assertEquals("Standard Latin layout with gesture typing", layout.description)
        assertTrue(layout.isQwertyBased())

        assertNotNull("numberRow must be defined", layout.numberRow)
        assertEquals(10, layout.numberRow!!.keys.size)
        assertEquals(listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "0"), layout.numberRow!!.keys.map { it.label })

        assertEquals(4, layout.rows.size)
        assertEquals(listOf("q", "w", "e", "r", "t", "y", "u", "i", "o", "p"), layout.rows[0].keys.map { it.label })
        assertNotNull("symbolsLayout must be defined", layout.symbolsLayout)
        assertNotNull("moreSymbolsLayout must be defined", layout.moreSymbolsLayout)
        assertEquals("symbols_1", layout.symbolsLayout!!.id)
        assertEquals("symbols_2", layout.moreSymbolsLayout!!.id)
    }

    @Test
    fun testLayoutFlagsAndExtraCompositionChars() {
        val json = kotlinx.serialization.json.Json { ignoreUnknownKeys = true }

        // 1. Single string flag
        val json1 = """{"id": "test1", "name": "Test 1", "flag": "NoAutoCapitalization"}"""
        val layout1 = json.decodeFromString<dev.darkdesign69.onlykeyboard.common.model.KeyboardLayoutDef>(json1)
        assertTrue(layout1.hasFlag("NoAutoCapitalization"))
        assertTrue(layout1.hasFlag("noautocapitalization"))
        assertTrue(layout1.noAutoCapitalization)
        assertFalse(layout1.noAutoSpace)

        // 2. Array flags
        val json2 = """{"id": "test2", "name": "Test 2", "flags": ["NoAutoCapitalization", "NoAutoSpace", "NoDoubleSpacePeriod", "NoRemoveSpaceBeforePunctuation"]}"""
        val layout2 = json.decodeFromString<dev.darkdesign69.onlykeyboard.common.model.KeyboardLayoutDef>(json2)
        assertTrue(layout2.noAutoCapitalization)
        assertTrue(layout2.noAutoSpace)
        assertTrue(layout2.noDoubleSpacePeriod)
        assertTrue(layout2.noRemoveSpaceBeforePunctuation)
        assertFalse(layout2.noSuggestions)

        // 3. Comma-separated flags
        val json3 = """{"id": "test3", "name": "Test 3", "flag": "NoSuggestions, NoLearnedWords, NoGesture"}"""
        val layout3 = json.decodeFromString<dev.darkdesign69.onlykeyboard.common.model.KeyboardLayoutDef>(json3)
        assertTrue(layout3.noSuggestions)
        assertTrue(layout3.noLearnedWords)
        assertTrue(layout3.noGesture)
        assertFalse(layout3.isQwertyBased())

        // 4. extraCompositionChars as JSON array
        val json4 = """{"id": "test4", "name": "Test 4", "extraCompositionChars": [",", "।"]}"""
        val layout4 = json.decodeFromString<dev.darkdesign69.onlykeyboard.common.model.KeyboardLayoutDef>(json4)
        assertEquals(listOf(",", "।"), layout4.extraCompositionChars)
        assertTrue(layout4.isExtraCompositionChar(","))
        assertTrue(layout4.isExtraCompositionChar("।"))
        assertFalse(layout4.isExtraCompositionChar("."))

        // 5. extraCompositionChars as single string
        val json5 = """{"id": "test5", "name": "Test 5", "extraCompositionChars": ",।"}"""
        val layout5 = json.decodeFromString<dev.darkdesign69.onlykeyboard.common.model.KeyboardLayoutDef>(json5)
        assertEquals(listOf(",", "।"), layout5.extraCompositionChars)
        assertTrue(layout5.isExtraCompositionChar(","))
        assertTrue(layout5.isExtraCompositionChar("।"))
    }
    @Test
    fun testDynamicEnterMoreKeys() {
        // 1. Enter key identification
        val actionKey = dev.darkdesign69.onlykeyboard.common.model.KeyDef(type = KeyType.ACTION)
        val iconEnterKey = dev.darkdesign69.onlykeyboard.common.model.KeyDef(icon = "enter")
        val normalKey = dev.darkdesign69.onlykeyboard.common.model.KeyDef(label = "a", moreKeys = listOf("à", "á"))

        assertTrue(actionKey.isEnterKey())
        assertTrue(iconEnterKey.isEnterKey())
        assertFalse(normalKey.isEnterKey())

        // 2. resolveActionMoreKeys
        assertEquals(listOf("ACTION_EMOJI", "ACTION_NEW_LINE"), actionKey.resolveActionMoreKeys())
        assertEquals(listOf("ACTION_EMOJI", "ACTION_NEW_LINE"), iconEnterKey.resolveActionMoreKeys())
        assertEquals(listOf("à", "á"), normalKey.resolveActionMoreKeys())

        val enterWithEmojiOnly = dev.darkdesign69.onlykeyboard.common.model.KeyDef(type = KeyType.ACTION, moreKeys = listOf("ACTION_EMOJI"))
        assertEquals(listOf("ACTION_EMOJI", "ACTION_NEW_LINE"), enterWithEmojiOnly.resolveActionMoreKeys())

        val enterWithNewLineOnly = dev.darkdesign69.onlykeyboard.common.model.KeyDef(type = KeyType.ACTION, moreKeys = listOf("ACTION_NEW_LINE"))
        assertEquals(listOf("ACTION_EMOJI", "ACTION_NEW_LINE"), enterWithNewLineOnly.resolveActionMoreKeys())

        // 3. moreKeys(ShiftState) dynamically returns both for enter keys
        assertEquals(listOf("ACTION_EMOJI", "ACTION_NEW_LINE"), actionKey.moreKeys(dev.darkdesign69.onlykeyboard.common.model.ShiftState.UNSHIFTED))
        assertEquals(listOf("ACTION_EMOJI", "ACTION_NEW_LINE"), actionKey.moreKeys(dev.darkdesign69.onlykeyboard.common.model.ShiftState.ONE_SHOT))
        assertEquals(listOf("ACTION_EMOJI", "ACTION_NEW_LINE"), actionKey.moreKeys(dev.darkdesign69.onlykeyboard.common.model.ShiftState.CAPS_LOCK))
        assertEquals(listOf("à", "á"), normalKey.moreKeys(dev.darkdesign69.onlykeyboard.common.model.ShiftState.UNSHIFTED))

        // 4. Predefined layout enter key verification
        val qwerty = PredefinedLayouts.fromId("en_qwerty")
        val qwertyEnter = qwerty.rows.last().keys.last()
        assertTrue(qwertyEnter.isEnterKey())
        assertEquals(listOf("ACTION_EMOJI"), qwertyEnter.moreKeys) // Raw JSON preserved
        assertEquals(listOf("ACTION_EMOJI", "ACTION_NEW_LINE"), qwertyEnter.moreKeys(dev.darkdesign69.onlykeyboard.common.model.ShiftState.UNSHIFTED))
    }

    @Test
    fun testBanglaPhoneticAndSymbolsPrioritization() {
        val borno = PredefinedLayouts.BengaliBorno
        val avro = PredefinedLayouts.BengaliAvro

        val expectedBnDigits = listOf("১", "২", "৩", "৪", "৫", "৬", "৭", "৮", "৯", "০")
        val expectedEnDigits = listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "0")

        // 1. Verify phonetic layouts top row (q..p) contains both Bangla and English digits
        for (layout in listOf(borno, avro)) {
            val topKeys = layout.rows[0].keys
            assertEquals(10, topKeys.size)
            for (i in 0 until 10) {
                val key = topKeys[i]
                assertTrue("Key ${key.label} must contain Bangla digit ${expectedBnDigits[i]}", key.moreKeys.contains(expectedBnDigits[i]))
                assertTrue("Key ${key.label} must contain English digit ${expectedEnDigits[i]}", key.moreKeys.contains(expectedEnDigits[i]))
            }

            // 2. Verify 'd' key flickUp and moreKeys prioritization
            val dKey = layout.rows[1].keys.first { it.label == "d" }
            assertEquals("৳", dKey.flickUp)
            assertEquals("৳", dKey.moreKeys[0])
            assertTrue(dKey.moreKeys.contains("$"))

            // 3. Verify symbols page has Bangla digits in row 0 and ৳ in row 1
            val sym = layout.symbolsLayout
            assertNotNull(sym)
            assertEquals(expectedBnDigits, sym!!.rows[0].keys.map { it.label })
            val takaKey = sym.rows[1].keys[2]
            assertEquals("৳", takaKey.label)
            assertEquals("৳", takaKey.moreKeys[0])
            assertTrue(takaKey.moreKeys.contains("$"))
        }

        // 4. Verify bn_unijoy.json symbols layout
        val unijoyFile = listOf(
            java.io.File("../../feature/ime/src/main/assets/layouts/bn_unijoy.json"),
            java.io.File("feature/ime/src/main/assets/layouts/bn_unijoy.json"),
            java.io.File("../feature/ime/src/main/assets/layouts/bn_unijoy.json")
        ).firstOrNull { it.exists() }
        assertNotNull("bn_unijoy.json must exist", unijoyFile)
        val unijoyLayout = kotlinx.serialization.json.Json { ignoreUnknownKeys = true }.decodeFromString<dev.darkdesign69.onlykeyboard.common.model.KeyboardLayoutDef>(unijoyFile!!.readText())
        val unijoySym = unijoyLayout.symbolsLayout
        assertNotNull(unijoySym)
        assertEquals(expectedBnDigits, unijoySym!!.rows[0].keys.map { it.label })
        val unijoyTakaKey = unijoySym.rows[1].keys[2]
        assertEquals("৳", unijoyTakaKey.label)
    }

    @Test
    fun testLayoutShiftKeySupport() {
        assertTrue(PredefinedLayouts.EnglishQwerty.hasShiftKey())
        assertTrue(PredefinedLayouts.BengaliBorno.hasShiftKey())
        assertTrue(PredefinedLayouts.BengaliAvro.hasShiftKey())
        assertTrue(PredefinedLayouts.BengaliProbhat.hasShiftKey())
        assertTrue(PredefinedLayouts.BengaliNational.hasShiftKey())
        assertFalse(PredefinedLayouts.BengaliBornoEasy.hasShiftKey())
        assertFalse(PredefinedLayouts.Symbols.hasShiftKey())
        assertFalse(PredefinedLayouts.SymbolsMore.hasShiftKey())
        assertFalse(PredefinedLayouts.NumberPadExtended.hasShiftKey())
    }

    @Test
    fun testDedicatedNumberRowNormalState() {
        val numberRowEn = PredefinedLayouts.NumberRowEn
        assertEquals(listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "0"), numberRowEn.keys.map { it.label })

        // In mobile standard, dedicated number row keys are always evaluated in UNSHIFTED state, committing digits
        numberRowEn.keys.forEach { key ->
            assertEquals(key.label, key.displayLabel(dev.darkdesign69.onlykeyboard.common.model.ShiftState.UNSHIFTED))
            assertEquals(key.commitText ?: key.label, key.textToCommit(dev.darkdesign69.onlykeyboard.common.model.ShiftState.UNSHIFTED))
        }

        val numberRowBn = PredefinedLayouts.NumberRowBn
        assertEquals(listOf("১", "২", "৩", "৪", "৫", "৬", "৭", "৮", "৯", "০"), numberRowBn.keys.map { it.label })
        numberRowBn.keys.forEach { key ->
            assertEquals(key.label, key.displayLabel(dev.darkdesign69.onlykeyboard.common.model.ShiftState.UNSHIFTED))
            assertEquals(key.commitText ?: key.label, key.textToCommit(dev.darkdesign69.onlykeyboard.common.model.ShiftState.UNSHIFTED))
        }
    }
}
